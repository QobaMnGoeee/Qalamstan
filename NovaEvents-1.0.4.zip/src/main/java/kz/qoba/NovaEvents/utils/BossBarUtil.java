package kz.qoba.NovaEvents.utils;

import java.util.HashMap;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BarColor;
import org.bukkit.entity.Player;
import org.bukkit.boss.BossBar;
import java.util.UUID;
import java.util.Map;

public class BossBarUtil
{
    private static final Map<UUID, BossBar> PLAYER_BARS;
    private static BossBar globalBar;
    
    public static void create(final Player player, final String title, final BarColor color, final BarStyle style, final double progress) {
        remove(player);
        final BossBar bossBar = Bukkit.createBossBar(title, color, style, new BarFlag[0]);
        bossBar.setProgress(clamp(progress));
        bossBar.addPlayer(player);
        bossBar.setVisible(true);
        BossBarUtil.PLAYER_BARS.put(player.getUniqueId(), bossBar);
    }
    
    public static void createGlobal(final String title, final BarColor color, final BarStyle style, final double progress) {
        removeGlobal();
        (BossBarUtil.globalBar = Bukkit.createBossBar(title, color, style, new BarFlag[0])).setProgress(clamp(progress));
        BossBarUtil.globalBar.setVisible(true);
        for (final Player player : Bukkit.getOnlinePlayers()) {
            BossBarUtil.globalBar.addPlayer(player);
        }
    }
    
    public static void setGlobalTitle(final String title) {
        if (BossBarUtil.globalBar != null) {
            BossBarUtil.globalBar.setTitle(title);
        }
    }
    
    public static void setGlobalProgress(final double progress) {
        if (BossBarUtil.globalBar != null) {
            BossBarUtil.globalBar.setProgress(clamp(progress));
        }
    }
    
    public static void addPlayerToGlobal(final Player player) {
        if (BossBarUtil.globalBar != null) {
            BossBarUtil.globalBar.addPlayer(player);
        }
    }
    
    public static void removeGlobal() {
        if (BossBarUtil.globalBar != null) {
            BossBarUtil.globalBar.removeAll();
            BossBarUtil.globalBar = null;
        }
    }
    
    public static void setTitle(final Player player, final String title) {
        final BossBar bossBar = BossBarUtil.PLAYER_BARS.get(player.getUniqueId());
        if (bossBar != null) {
            bossBar.setTitle(title);
        }
    }
    
    public static void setProgress(final Player player, final double progress) {
        final BossBar bossBar = BossBarUtil.PLAYER_BARS.get(player.getUniqueId());
        if (bossBar != null) {
            bossBar.setProgress(clamp(progress));
        }
    }
    
    public static void setColor(final Player player, final BarColor color) {
        final BossBar bossBar = BossBarUtil.PLAYER_BARS.get(player.getUniqueId());
        if (bossBar != null) {
            bossBar.setColor(color);
        }
    }
    
    public static void remove(final Player player) {
        final BossBar bossBar = BossBarUtil.PLAYER_BARS.remove(player.getUniqueId());
        if (bossBar != null) {
            bossBar.removeAll();
        }
    }
    
    public static void removeAll() {
        for (final BossBar bossBar : BossBarUtil.PLAYER_BARS.values()) {
            bossBar.removeAll();
        }
        BossBarUtil.PLAYER_BARS.clear();
        removeGlobal();
    }
    
    public static BossBar get(final Player player) {
        return BossBarUtil.PLAYER_BARS.get(player.getUniqueId());
    }
    
    public static boolean exists(final Player player) {
        return BossBarUtil.PLAYER_BARS.containsKey(player.getUniqueId());
    }
    
    public static BarColor parseColor(final String input) {
        if (input == null) {
            return BarColor.WHITE;
        }
        try {
            return BarColor.valueOf(input.toUpperCase());
        }
        catch (final IllegalArgumentException var2) {
            return BarColor.WHITE;
        }
    }
    
    public static BarStyle parseStyle(final String input) {
        if (input == null) {
            return BarStyle.SOLID;
        }
        try {
            return BarStyle.valueOf(input.toUpperCase());
        }
        catch (final IllegalArgumentException var2) {
            return BarStyle.SOLID;
        }
    }
    
    private static double clamp(final double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }
    
    static {
        PLAYER_BARS = new HashMap<UUID, BossBar>();
    }
}
