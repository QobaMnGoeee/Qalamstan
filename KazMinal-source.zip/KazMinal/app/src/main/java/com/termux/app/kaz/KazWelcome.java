package com.termux.app.kaz;

import com.termux.shared.termux.TermuxConstants;

import java.io.File;
import java.io.FileOutputStream;

/** Silences the login welcome message (MOTD) of the shell. */
public final class KazWelcome {

    private KazWelcome() {}

    public static void suppress() {
        try {
            File home = new File(TermuxConstants.TERMUX_HOME_DIR_PATH);
            if (home.isDirectory()) {
                File hush = new File(home, ".hushlogin");
                if (!hush.exists()) hush.createNewFile();
            }
            File motd = new File(TermuxConstants.TERMUX_ETC_PREFIX_DIR_PATH, "motd");
            if (motd.isFile() && motd.length() > 0) {
                new FileOutputStream(motd, false).close();
            }
        } catch (Exception ignored) {
        }
    }
}
