package com.termux.app.kaz;

import android.content.Context;
import android.content.SharedPreferences;

/** Persists the user's choice of theme, font and snow overlay. */
public final class KazPrefs {

    private static final String FILE = "kazminal_ui";
    private static final String KEY_THEME = "theme";
    private static final String KEY_FONT = "font";
    private static final String KEY_SNOW = "snow_overlay";

    private KazPrefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static int getThemeIndex(Context c) {
        int i = sp(c).getInt(KEY_THEME, KazTheme.DEFAULT_INDEX);
        return (i >= 0 && i < KazTheme.ALL.length) ? i : KazTheme.DEFAULT_INDEX;
    }

    public static void setThemeIndex(Context c, int i) {
        sp(c).edit().putInt(KEY_THEME, i).apply();
    }

    public static int getFontIndex(Context c) {
        int i = sp(c).getInt(KEY_FONT, KazFont.DEFAULT_INDEX);
        return (i >= 0 && i < KazFont.ALL.length) ? i : KazFont.DEFAULT_INDEX;
    }

    public static void setFontIndex(Context c, int i) {
        sp(c).edit().putInt(KEY_FONT, i).apply();
    }

    public static boolean isSnowOverlay(Context c) {
        return sp(c).getBoolean(KEY_SNOW, true);
    }

    public static void setSnowOverlay(Context c, boolean on) {
        sp(c).edit().putBoolean(KEY_SNOW, on).apply();
    }

    public static KazTheme theme(Context c) {
        return KazTheme.ALL[getThemeIndex(c)];
    }

    public static KazFont font(Context c) {
        return KazFont.ALL[getFontIndex(c)];
    }
}
