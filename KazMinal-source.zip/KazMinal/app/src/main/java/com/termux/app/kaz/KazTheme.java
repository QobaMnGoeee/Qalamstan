package com.termux.app.kaz;

import java.util.Properties;

/**
 * KazMinal winter themes. Every theme carries both the UI palette (soft-UI "neumorphic" panel)
 * and the full terminal colour scheme (foreground, background, cursor and the 16 ANSI colours).
 */
public final class KazTheme {

    public final String id;
    /** Display name (Kazakh). */
    public final String name;
    /** Short description (Kazakh). */
    public final String tagline;
    public final boolean dark;

    // ---- UI palette ----
    /** Panel gradient, top. */
    public final int bgTop;
    /** Panel gradient, bottom. */
    public final int bgBottom;
    /** Neumorphic surface colour (should sit between bgTop and bgBottom). */
    public final int surface;
    /** Neumorphic highlight (top-left light). */
    public final int shadowLight;
    /** Neumorphic shadow (bottom-right dark). */
    public final int shadowDark;
    public final int text;
    public final int subText;
    public final int accent;
    public final int accent2;
    /** Colour of the snow-drift / frost ornaments. */
    public final int frost;

    // ---- Terminal palette ----
    public final int termFg;
    public final int termBg;
    public final int termCursor;
    public final int[] ansi;

    private KazTheme(String id, String name, String tagline, boolean dark,
                     int bgTop, int bgBottom, int surface, int shadowLight, int shadowDark,
                     int text, int subText, int accent, int accent2, int frost,
                     int termFg, int termBg, int termCursor, int[] ansi) {
        this.id = id;
        this.name = name;
        this.tagline = tagline;
        this.dark = dark;
        this.bgTop = bgTop;
        this.bgBottom = bgBottom;
        this.surface = surface;
        this.shadowLight = shadowLight;
        this.shadowDark = shadowDark;
        this.text = text;
        this.subText = subText;
        this.accent = accent;
        this.accent2 = accent2;
        this.frost = frost;
        this.termFg = termFg;
        this.termBg = termBg;
        this.termCursor = termCursor;
        this.ansi = ansi;
    }

    /** Builds the property set understood by {@code TerminalColorScheme.updateWith()}. */
    public Properties toTerminalProperties() {
        Properties p = new Properties();
        p.setProperty("foreground", hex(termFg));
        p.setProperty("background", hex(termBg));
        p.setProperty("cursor", hex(termCursor));
        for (int i = 0; i < 16; i++) p.setProperty("color" + i, hex(ansi[i]));
        return p;
    }

    private static String hex(int argb) {
        return String.format("#%06x", argb & 0xFFFFFF);
    }

    public static final int DEFAULT_INDEX = 0;

    public static final KazTheme[] ALL = new KazTheme[]{

        // 1. Light, icy blue
        new KazTheme("frost", "Мұз", "Ашық · мұздай көгілдір", false,
            0xFFEEF7FE, 0xFFD5E8F7, 0xFFE2F0FB, 0xFFFFFFFF, 0xFFA3C0DA,
            0xFF1F3B5C, 0xFF5C7C9C, 0xFF2F8BE6, 0xFF7FD0FF, 0xFFFFFFFF,
            0xFF1E3A5F, 0xFFF4FAFF, 0xFF2F8BE6,
            new int[]{
                0xFF3B5373, 0xFFD64550, 0xFF2E9E6B, 0xFFC08A1B, 0xFF2F6FD6, 0xFF9A5BD6, 0xFF1A9CB0, 0xFF8DA3BC,
                0xFF5E7A99, 0xFFF05D6C, 0xFF3DBE86, 0xFFD9A52B, 0xFF4A8CF0, 0xFFB47CF0, 0xFF2BB5CC, 0xFF5B7694}),

        // 2. Dark navy
        new KazTheme("night", "Полярлық түн", "Қараңғы · терең көк", true,
            0xFF1A2B45, 0xFF0D192C, 0xFF132238, 0xFF22385A, 0xFF060D19,
            0xFFDCEEFF, 0xFF8FAFCF, 0xFF5CC8FF, 0xFFA5E5FF, 0xFFDCEEFF,
            0xFFD6ECFF, 0xFF0B1626, 0xFF5CC8FF,
            new int[]{
                0xFF1B2B44, 0xFFFF6B81, 0xFF6EE7B7, 0xFFFFD479, 0xFF6AA9FF, 0xFFC4A1FF, 0xFF5CE1E6, 0xFFC8D8EA,
                0xFF3C5578, 0xFFFF8FA0, 0xFF8FF2C9, 0xFFFFE29C, 0xFF8DC0FF, 0xFFD8BDFF, 0xFF8CF0F2, 0xFFFFFFFF}),

        // 3. Dark teal / violet aurora
        new KazTheme("aurora", "Аврора", "Қараңғы · солтүстік шұғыласы", true,
            0xFF16403F, 0xFF1B1B42, 0xFF182B3E, 0xFF264A5C, 0xFF09121E,
            0xFFE4FFF4, 0xFF8FC9B8, 0xFF4DFFB4, 0xFFB388FF, 0xFFE8FFF8,
            0xFFDDFBEF, 0xFF0B1B22, 0xFF4DFFB4,
            new int[]{
                0xFF16303A, 0xFFFF7A9A, 0xFF4DFFB4, 0xFFF7E26B, 0xFF6FB6FF, 0xFFB388FF, 0xFF46E6D8, 0xFFCFEFE4,
                0xFF34545F, 0xFFFF9DB5, 0xFF86FFCC, 0xFFFFF08F, 0xFF98CCFF, 0xFFCDB0FF, 0xFF86F5EA, 0xFFFFFFFF}),

        // 4. Light, rosy dawn over snow
        new KazTheme("dawn", "Қарлы таң", "Ашық · қызғылт-көгілдір таң", false,
            0xFFFFF4F7, 0xFFE6DDF3, 0xFFF1E8F5, 0xFFFFFFFF, 0xFFC9B6D6,
            0xFF3E3560, 0xFF7D72A0, 0xFFE0577F, 0xFF7B8CFF, 0xFFFFFFFF,
            0xFF3E3560, 0xFFFBF4F8, 0xFFE0577F,
            new int[]{
                0xFF4A4268, 0xFFD6456B, 0xFF3E9E78, 0xFFC48A2C, 0xFF5470D8, 0xFFA55BD0, 0xFF2A9DAA, 0xFF9A90B8,
                0xFF6E6590, 0xFFF0668A, 0xFF54B88F, 0xFFDDA040, 0xFF6F8BF0, 0xFFBE78E6, 0xFF43B6C2, 0xFF7C7399}),
    };
}
