package com.termux.app.kaz;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.animation.DecelerateInterpolator;
import android.widget.TextView;

/**
 * Soft-UI button. Raised at rest, sinks into the surface while pressed (animated) and can stay
 * sunk with an accent ring when "selected" (used for tabs, chosen cards and toggles).
 */
public class NeuButton extends TextView {

    private final NeuDrawable bg;
    private final int contentPadH;
    private final int contentPadV;

    private ValueAnimator pressAnim;
    private boolean selectedLook;
    private int textColor = 0xFF1F3B5C;
    private int selectedTextColor = 0xFF2F8BE6;

    public NeuButton(Context context) {
        this(context, null);
    }

    public NeuButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        float d = context.getResources().getDisplayMetrics().density;
        bg = new NeuDrawable(14f * d, 5f * d);
        bg.setRing(0xFF2F8BE6, 2f * d);
        setBackground(bg);
        contentPadH = Math.round(10 * d);
        contentPadV = Math.round(6 * d);
        int in = bg.getInset();
        setPadding(in + contentPadH, in + contentPadV, in + contentPadH, in + contentPadV);
        setGravity(Gravity.CENTER);
        setClickable(true);
        setFocusable(true);
        setSingleLine(true);
        setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        setTextSize(14f);
        setAllCaps(false);
        setMinHeight(Math.round(48 * d) + 2 * in);
    }

    public void applyPalette(KazTheme t) {
        bg.setColors(t.surface, t.shadowLight, t.shadowDark);
        bg.setRing(t.accent, 2f * getResources().getDisplayMetrics().density);
        textColor = t.text;
        selectedTextColor = t.accent;
        refreshText();
    }

    /** Keeps the button pressed-in with an accent ring (tab / toggle on state). */
    public void setSelectedLook(boolean on, boolean animate) {
        selectedLook = on;
        refreshText();
        animatePressTo(on ? 1f : 0f, animate);
        float ringTarget = on ? 1f : 0f;
        bg.setRingAlpha(ringTarget);
    }

    public boolean hasSelectedLook() {
        return selectedLook;
    }

    private void refreshText() {
        setTextColor(selectedLook ? selectedTextColor : textColor);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                animatePressTo(1f, true);
                animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start();
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                animatePressTo(selectedLook ? 1f : 0f, true);
                animate().scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(new DecelerateInterpolator()).start();
                break;
            default:
                break;
        }
        return super.onTouchEvent(e);
    }

    private void animatePressTo(float target, boolean animate) {
        if (pressAnim != null) pressAnim.cancel();
        if (!animate) {
            bg.setPress(target);
            return;
        }
        pressAnim = ValueAnimator.ofFloat(bg.getPress(), target);
        pressAnim.setDuration(140);
        pressAnim.addUpdateListener(a -> bg.setPress((Float) a.getAnimatedValue()));
        pressAnim.start();
    }
}
