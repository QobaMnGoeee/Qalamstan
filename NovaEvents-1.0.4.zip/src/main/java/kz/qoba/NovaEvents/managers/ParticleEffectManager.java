package kz.qoba.NovaEvents.managers;

import org.bukkit.Particle;
import java.util.logging.Level;
import java.util.ArrayList;
import org.bukkit.Bukkit;
import com.sk89q.worldedit.math.BlockVector3;
import org.bukkit.Location;
import org.bukkit.plugin.Plugin;
import java.util.Iterator;
import com.sk89q.worldedit.regions.CuboidRegion;
import org.bukkit.World;
import kz.qoba.NovaEvents.models.EventParticleConfig;
import java.util.List;
import org.bukkit.scheduler.BukkitRunnable;
import kz.qoba.NovaEvents.models.EventStage;
import kz.qoba.NovaEvents.models.ActiveEventData;
import kz.qoba.NovaEvents.models.EventModel;
import java.util.HashSet;
import java.util.Set;
import java.util.Random;
import kz.qoba.NovaEvents.NovaEvents;

public class ParticleEffectManager
{
    private final NovaEvents plugin;
    private final Random random;
    private final Set<String> warnedParticleTypes;
    
    public ParticleEffectManager(final NovaEvents plugin) {
        this.random = new Random();
        this.warnedParticleTypes = new HashSet<String>();
        this.plugin = plugin;
    }
    
    public void startForStage(final EventModel model, final ActiveEventData data, final EventStage stage) {
        this.stop(data);
        final List<EventParticleConfig> configs = this.resolveParticles(model, stage);
        if (!configs.isEmpty()) {
            final int taskId = new BukkitRunnable() {
                private int tick;
                
                public void run() {
                    if (model.getState() != EventModel.EventState.IDLE && model.getActiveData() == data) {
                        final World world = data.getSpawnLocation().getWorld();
                        final CuboidRegion region = ParticleEffectManager.this.resolveParticleRegion(model, data);
                        if (world != null && region != null) {
                            ++this.tick;
                            for (final EventParticleConfig config : configs) {
                                if (config.isEnabled() && this.tick % config.getIntervalTicks() == 0) {
                                    ParticleEffectManager.this.spawnEffect(world, region, config);
                                }
                            }
                        }
                    }
                    else {
                        this.cancel();
                    }
                }
            }.runTaskTimer((Plugin)this.plugin, 0L, 1L).getTaskId();
            data.setParticleTaskId(taskId);
        }
    }
    
    public CuboidRegion resolveParticleRegion(final EventModel model, final ActiveEventData data) {
        if (data.getSavedRegion() != null) {
            return data.getSavedRegion();
        }
        if (data.getParticleRegion() != null) {
            return data.getParticleRegion();
        }
        final Location center = (data.getShulkerLocation() != null) ? data.getShulkerLocation() : data.getSpawnLocation();
        return this.createRegionAround(center, model.getParticleRadius());
    }
    
    public CuboidRegion createRegionAround(final Location center, final int radius) {
        final int r = Math.max(1, radius);
        final BlockVector3 min = BlockVector3.at(center.getBlockX() - r, center.getBlockY() - r, center.getBlockZ() - r);
        final BlockVector3 max = BlockVector3.at(center.getBlockX() + r, center.getBlockY() + r, center.getBlockZ() + r);
        return new CuboidRegion(min, max);
    }
    
    public void stop(final ActiveEventData data) {
        if (data != null && data.getParticleTaskId() != -1) {
            Bukkit.getScheduler().cancelTask(data.getParticleTaskId());
            data.setParticleTaskId(-1);
        }
    }
    
    public List<EventParticleConfig> resolveParticles(final EventModel model, final EventStage stage) {
        final List<EventParticleConfig> stageParticles = (stage == null) ? List.of() : stage.getParticles();
        return (stageParticles != null && !stageParticles.isEmpty()) ? this.filterEnabled(stageParticles) : this.filterEnabled(model.getParticles());
    }
    
    private List<EventParticleConfig> filterEnabled(final List<EventParticleConfig> configs) {
        final List<EventParticleConfig> enabled = new ArrayList<EventParticleConfig>();
        for (final EventParticleConfig config : configs) {
            if (config.isEnabled()) {
                enabled.add(config);
            }
        }
        return enabled;
    }
    
    private void spawnEffect(final World world, final CuboidRegion region, final EventParticleConfig config) {
        final Particle particle = config.resolveParticle();
        if (particle == null) {
            if (this.warnedParticleTypes.add(config.getTypeName().toUpperCase())) {
                this.plugin.getLogger().log(Level.WARNING, "Unknown particle type: " + config.getTypeName());
            }
        }
        else {
            final Location location = this.randomSurfaceLocation(world, region, config);
            final Object particleData = config.resolveParticleData(particle);
            final double spread = 0.15;
            if (particleData != null) {
                world.spawnParticle(particle, location, config.getCount(), spread, spread, spread, config.getSpeed(), particleData);
            }
            else {
                world.spawnParticle(particle, location, config.getCount(), spread, spread, spread, config.getSpeed());
            }
        }
    }
    
    private Location randomSurfaceLocation(final World world, final CuboidRegion region, final EventParticleConfig config) {
        final BlockVector3 min = region.getMinimumPoint();
        final BlockVector3 max = region.getMaximumPoint();
        final int spreadBlocks = (int)Math.ceil(config.getSpread());
        final int minX = min.x() - spreadBlocks;
        final int maxX = max.x() + spreadBlocks;
        int minY = min.y() + config.getOffsetY();
        int maxY = max.y() + config.getOffsetY();
        final int minZ = min.z() - spreadBlocks;
        final int maxZ = max.z() + spreadBlocks;
        if (minY > maxY) {
            final int tmp = minY;
            minY = maxY;
            maxY = tmp;
        }
        double x = 0.0;
        double y = 0.0;
        double z = 0.0;
        switch (this.random.nextInt(6)) {
            case 0: {
                x = minX + 0.5;
                y = minY + this.random.nextDouble() * Math.max(1, maxY - minY + 1);
                z = minZ + this.random.nextDouble() * Math.max(1, maxZ - minZ + 1);
                break;
            }
            case 1: {
                x = maxX + 0.5;
                y = minY + this.random.nextDouble() * Math.max(1, maxY - minY + 1);
                z = minZ + this.random.nextDouble() * Math.max(1, maxZ - minZ + 1);
                break;
            }
            case 2: {
                x = minX + this.random.nextDouble() * Math.max(1, maxX - minX + 1);
                y = minY + 0.5;
                z = minZ + this.random.nextDouble() * Math.max(1, maxZ - minZ + 1);
                break;
            }
            case 3: {
                x = minX + this.random.nextDouble() * Math.max(1, maxX - minX + 1);
                y = maxY + 0.5;
                z = minZ + this.random.nextDouble() * Math.max(1, maxZ - minZ + 1);
                break;
            }
            case 4: {
                x = minX + this.random.nextDouble() * Math.max(1, maxX - minX + 1);
                y = minY + this.random.nextDouble() * Math.max(1, maxY - minY + 1);
                z = minZ + 0.5;
                break;
            }
            default: {
                x = minX + this.random.nextDouble() * Math.max(1, maxX - minX + 1);
                y = minY + this.random.nextDouble() * Math.max(1, maxY - minY + 1);
                z = maxZ + 0.5;
                break;
            }
        }
        return new Location(world, x, y, z);
    }
}
