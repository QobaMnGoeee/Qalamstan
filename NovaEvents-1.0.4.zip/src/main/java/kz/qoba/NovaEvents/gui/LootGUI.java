package kz.qoba.NovaEvents.gui;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Bukkit;
import org.bukkit.inventory.InventoryHolder;
import kz.qoba.NovaEvents.utils.ColorUtil;
import org.bukkit.inventory.Inventory;
import kz.qoba.NovaEvents.models.EventModel;
import kz.qoba.NovaEvents.NovaEvents;

public class LootGUI
{
    private final NovaEvents plugin;
    
    public LootGUI(final NovaEvents plugin) {
        this.plugin = plugin;
    }
    
    public Inventory buildLootGUI(final EventModel model) {
        final int size = this.plugin.getConfigManager().normalizeInventorySize(model.getLootEditorSize());
        final String title = ColorUtil.colorize("&8» &f\u041b\u0443\u0442: " + ColorUtil.colorize(model.getDisplayName()) + " &8«");
        final Inventory inv = Bukkit.createInventory((InventoryHolder)null, size, title);
        final List<ItemStack> loot = model.getLoot();
        if (loot != null) {
            for (int i = 0; i < Math.min(loot.size(), size); ++i) {
                final ItemStack item = loot.get(i);
                if (item != null) {
                    inv.setItem(i, item.clone());
                }
            }
        }
        return inv;
    }
    
    public List<ItemStack> extractLoot(final Inventory inv) {
        final List<ItemStack> loot = new ArrayList<ItemStack>();
        for (final ItemStack item : inv.getContents()) {
            if (item != null) {
                loot.add(item.clone());
            }
        }
        return loot;
    }
}
