# KazMinal ❄ — Termux 0.118.3 форкі

Қысқы дизайндағы, soft-UI (neumorphism) стиліндегі Termux. Пакет атауы (`com.termux`), `applicationId`,
Java пакеттері және bootstrap жолдары **өзгертілмеген** (сондықтан бұрынғы пакеттер мен плагиндер жұмыс істей береді).
Өзгергені: көрінетін атау → **KazMinal**, иконка, дизайн, жаңа функциялар.

## Не қосылды
* **Оңға swipe панелі** (қысқы дизайн: мұз сүңгілері, қар жиегі, жылтырайтын ромб/жұлдыздар, қар жауу):
  * **Сессия** — сессиялар тізімі (soft-UI карточкалар, ағымдағысы «басылып» тұрады).
  * **Тема** — 4 тема: *Мұз* (ашық), *Полярлық түн* (қараңғы), *Аврора* (қараңғы), *Қарлы таң* (ашық).
    Әр тема терминалдың толық түс схемасын (fg/bg/cursor + 16 ANSI) және панель/құралдар тақтасы түстерін береді.
  * **Қаріп** — 8 қаріп, барлығында қазақ әріптері бар (ә і ң ғ ү ұ қ ө һ):
    Fira Mono, Source Code Pro, IBM Plex Mono, Ubuntu Mono, Roboto Mono, PT Mono, Overpass Mono, Noto Sans Mono.
  * «Терминал үстінде қар» қосқышы (терминалдың үстінде жеңіл қар және жиегінде аязды сүңгілер; тырнақпен басуға кедергі жасамайды).
* Таңдау сақталады (`SharedPreferences: kazminal_ui`).
* Жаңа иконка: түнгі қысқы аспан, қар төбелері, `>_` белгісі бар мұз «гауһары».

## Негізгі файлдар
```
app/src/main/java/com/termux/app/kaz/   KazTheme, KazFont, KazPrefs, KazPanel, NeuDrawable, NeuButton,
                                        HexButton, SnowView, KazPanelBackground, ThemePreview, KazUi
app/src/main/assets/fonts/              8 қаріп (+ LICENSES.txt)
app/src/main/res/layout/activity_termux.xml   жаңа панель макеті
app/src/main/res/values/kaz_strings.xml       қазақша жолдар (values-en — ағылшынша)
```
Түстерді өзгерту: `KazTheme.java`. Қаріп қосу: `.ttf` файлын `assets/fonts/` ішіне салып, `KazFont.ALL` тізіміне жол қосыңыз.

## Құрастыру
APK-ны бұлтта жинау (ең оңай): жобаны GitHub-қа жүктеп, **Actions → Build → Run workflow**. Нәтиже — `kazminal_*_universal.apk`.
Не болмаса компьютерде (JDK 17 + Android SDK, NDK 22.1.7171670):
```
./gradlew assembleDebug
```
APK: `app/build/outputs/apk/debug/`.

## Ескертпелер
* Таңдалған тема/қаріп `~/.termux/colors.properties` және `~/.termux/font.ttf` файлдарынан басым.
* Түстер мен қаріптерді қолданғанда терминал қайта жүктеледі, ашық сессиялар жабылмайды.
* Лицензия: Termux — GPLv3 (`LICENSE.md`), форк та GPLv3 болып қалуы керек. Қаріп лицензиялары — `assets/fonts/LICENSES.txt`.
* Бұл жерде сыртқы Android SDK болмағандықтан, толық APK құрастырылып, құрылғыда сыналған жоқ: жаңа Java сыныптары `javac` арқылы
  компиляциядан өтті, XML/ресурс сілтемелері тексерілді, бірақ UI көрінісін алғаш рет өзіңіз телефонда көресіз.
