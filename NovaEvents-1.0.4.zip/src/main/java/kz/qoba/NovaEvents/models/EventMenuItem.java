package kz.qoba.NovaEvents.models;

import org.bukkit.configuration.ConfigurationSection;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Material;

public class EventMenuItem
{
    private final Material material;
    private final String name;
    private final List<String> lore;
    private final int slot;
    
    public EventMenuItem(final Material material, final String name, final List<String> lore, final int slot) {
        this.material = material;
        this.name = name;
        this.lore = ((lore == null) ? new ArrayList<String>() : new ArrayList<String>(lore));
        this.slot = slot;
    }
    
    public static EventMenuItem fromSection(final ConfigurationSection section, final int defaultSlot) {
        Material material = Material.BLAZE_POWDER;
        final String materialName = section.getString("material", "BLAZE_POWDER");
        try {
            material = Material.valueOf(materialName.toUpperCase());
        }
        catch (final IllegalArgumentException ex) {}
        final String name = section.getString("name", "&e{event_name}");
        final List<String> lore = section.getStringList("lore");
        final int slot = section.getInt("slot", defaultSlot);
        return new EventMenuItem(material, name, lore, slot);
    }
    
    public Material getMaterial() {
        return this.material;
    }
    
    public String getName() {
        return this.name;
    }
    
    public List<String> getLore() {
        return this.lore;
    }
    
    public int getSlot() {
        return this.slot;
    }
}
