package kz.qoba.NovaEvents.utils;

import org.bukkit.inventory.ItemFlag;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.function.Function;
import java.util.Arrays;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.ItemStack;

public class ItemBuilder
{
    private final ItemStack item;
    private final ItemMeta meta;
    
    public ItemBuilder(final Material material) {
        this.item = new ItemStack(material);
        this.meta = this.item.getItemMeta();
    }
    
    public ItemBuilder name(final String name) {
        this.meta.setDisplayName(ColorUtil.colorize(name));
        return this;
    }
    
    public ItemBuilder lore(final String... lines) {
        this.meta.setLore((List)Arrays.stream(lines).map((Function<? super String, ?>)ColorUtil::colorize).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
        return this;
    }
    
    public ItemBuilder lore(final List<String> lines) {
        this.meta.setLore((List)lines.stream().map((Function<? super Object, ?>)ColorUtil::colorize).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
        return this;
    }
    
    public ItemBuilder flags(final ItemFlag... flags) {
        this.meta.addItemFlags(flags);
        return this;
    }
    
    public ItemBuilder amount(final int amount) {
        this.item.setAmount(amount);
        return this;
    }
    
    public ItemStack build() {
        this.item.setItemMeta(this.meta);
        return this.item;
    }
}
