package kz.qoba.NovaEvents;

import org.bukkit.plugin.Plugin;
import org.bukkit.event.Listener;
import kz.qoba.NovaEvents.listeners.PlayerListener;
import org.bukkit.command.TabCompleter;
import org.bukkit.command.CommandExecutor;
import kz.qoba.NovaEvents.commands.AEventsCommand;
import kz.qoba.NovaEvents.managers.WorldGuardRegionManager;
import kz.qoba.NovaEvents.managers.ParticleEffectManager;
import kz.qoba.NovaEvents.managers.SchematicManager;
import kz.qoba.NovaEvents.managers.HologramManager;
import kz.qoba.NovaEvents.managers.EventManager;
import kz.qoba.NovaEvents.managers.ConfigManager;
import org.bukkit.plugin.java.JavaPlugin;

public class NovaEvents extends JavaPlugin
{
    private static NovaEvents instance;
    private ConfigManager configManager;
    private EventManager eventManager;
    private HologramManager hologramManager;
    private SchematicManager schematicManager;
    private ParticleEffectManager particleEffectManager;
    private WorldGuardRegionManager worldGuardRegionManager;
    
    public void onEnable() {
        (NovaEvents.instance = this).saveDefaultConfig();
        this.configManager = new ConfigManager(this);
        this.schematicManager = new SchematicManager(this);
        this.particleEffectManager = new ParticleEffectManager(this);
        this.worldGuardRegionManager = new WorldGuardRegionManager(this);
        this.hologramManager = new HologramManager(this);
        this.eventManager = new EventManager(this);
        final AEventsCommand aEventsCommand = new AEventsCommand(this);
        this.getCommand("aevents").setExecutor((CommandExecutor)aEventsCommand);
        this.getCommand("aevents").setTabCompleter((TabCompleter)aEventsCommand);
        this.getServer().getPluginManager().registerEvents((Listener)new PlayerListener(this), (Plugin)this);
        this.eventManager.startScheduler();
        this.getLogger().info("NovaEvents v" + this.getDescription().getVersion() + " \u0456\u0441\u043a\u0435 \u049b\u043e\u0441\u044b\u043b\u0434\u044b! (\u0410\u0432\u0442\u043e\u0440: QobaMn)");
    }
    
    public void onDisable() {
        if (this.eventManager != null) {
            this.eventManager.stopAll();
        }
        this.getLogger().info("NovaEvents \u04e9\u0448\u0456\u0440\u0456\u043b\u0434\u0456.");
    }
    
    public static NovaEvents getInstance() {
        return NovaEvents.instance;
    }
    
    public ConfigManager getConfigManager() {
        return this.configManager;
    }
    
    public EventManager getEventManager() {
        return this.eventManager;
    }
    
    public HologramManager getHologramManager() {
        return this.hologramManager;
    }
    
    public SchematicManager getSchematicManager() {
        return this.schematicManager;
    }
    
    public ParticleEffectManager getParticleEffectManager() {
        return this.particleEffectManager;
    }
    
    public WorldGuardRegionManager getWorldGuardRegionManager() {
        return this.worldGuardRegionManager;
    }
}
