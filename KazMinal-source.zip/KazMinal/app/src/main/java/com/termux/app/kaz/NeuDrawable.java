package com.termux.app.kaz;

import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * Soft-UI ("neumorphic") surface: a rounded rectangle that is either extruded (raised) or
 * pressed into the background (sunk). Both looks are rendered once into cached bitmaps with a
 * software canvas (so blur works on every API level) and cross-faded by {@link #setPress(float)}.
 *
 * The visible shape is inset from the drawable bounds by {@link #getInset()} so the shadows have
 * room to spread without being clipped by the parent.
 */
public class NeuDrawable extends Drawable {

    private final float radius;
    private final float elevation;
    private final float inset;

    private int surface = 0xFFE2F0FB;
    private int light = 0xFFFFFFFF;
    private int dark = 0xFFA3C0DA;
    private int ring = 0;

    private float press = 0f;
    private float ringAlpha = 0f;

    private Bitmap raised;
    private Bitmap sunk;

    private final Paint bitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmp = new RectF();

    public NeuDrawable(float radiusPx, float elevationPx) {
        this.radius = radiusPx;
        this.elevation = elevationPx;
        this.inset = (float) Math.ceil(elevationPx * 1.9f);
        ringPaint.setStyle(Paint.Style.STROKE);
    }

    /** Distance between the drawable bounds and the visible shape. */
    public int getInset() {
        return Math.round(inset);
    }

    public void setColors(int surface, int light, int dark) {
        if (this.surface == surface && this.light == light && this.dark == dark) return;
        this.surface = surface;
        this.light = light;
        this.dark = dark;
        releaseBitmaps();
        invalidateSelf();
    }

    /** Accent ring drawn around the shape; its visibility is driven by {@link #setRingAlpha}. */
    public void setRing(int color, float strokePx) {
        this.ring = color;
        ringPaint.setStrokeWidth(strokePx);
        invalidateSelf();
    }

    public void setRingAlpha(float a) {
        this.ringAlpha = Math.max(0f, Math.min(1f, a));
        invalidateSelf();
    }

    public float getRingAlpha() {
        return ringAlpha;
    }

    /** 0 = fully raised, 1 = fully pressed in. */
    public void setPress(float p) {
        p = Math.max(0f, Math.min(1f, p));
        if (p == press) return;
        press = p;
        invalidateSelf();
    }

    public float getPress() {
        return press;
    }

    @Override
    protected void onBoundsChange(Rect bounds) {
        releaseBitmaps();
    }

    private void releaseBitmaps() {
        raised = null;
        sunk = null;
    }

    @Override
    public void draw(Canvas canvas) {
        Rect b = getBounds();
        if (b.width() <= 0 || b.height() <= 0) return;

        if (press < 1f) {
            if (raised == null) raised = renderRaised(b.width(), b.height());
            bitmapPaint.setAlpha(Math.round(255 * (1f - press)));
            canvas.drawBitmap(raised, b.left, b.top, bitmapPaint);
        }
        if (press > 0f) {
            if (sunk == null) sunk = renderSunk(b.width(), b.height());
            bitmapPaint.setAlpha(Math.round(255 * press));
            canvas.drawBitmap(sunk, b.left, b.top, bitmapPaint);
        }
        if (ringAlpha > 0f && ring != 0) {
            float half = ringPaint.getStrokeWidth() / 2f;
            tmp.set(b.left + inset + half, b.top + inset + half, b.right - inset - half, b.bottom - inset - half);
            ringPaint.setColor(KazUi.withAlpha(ring, Math.round(255 * ringAlpha)));
            canvas.drawRoundRect(tmp, radius, radius, ringPaint);
        }
    }

    private Bitmap renderRaised(int w, int h) {
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        RectF r = new RectF(inset, inset, w - inset, h - inset);
        float off = elevation * 0.62f;

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setMaskFilter(new BlurMaskFilter(Math.max(1f, elevation), BlurMaskFilter.Blur.NORMAL));

        p.setColor(dark);
        c.save();
        c.translate(off, off);
        c.drawRoundRect(r, radius, radius, p);
        c.restore();

        p.setColor(light);
        c.save();
        c.translate(-off, -off);
        c.drawRoundRect(r, radius, radius, p);
        c.restore();

        p.setMaskFilter(null);
        p.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom,
            KazUi.lighten(surface, 0.30f), KazUi.mix(surface, dark, 0.14f), Shader.TileMode.CLAMP));
        c.drawRoundRect(r, radius, radius, p);
        return bmp;
    }

    private Bitmap renderSunk(int w, int h) {
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        RectF r = new RectF(inset, inset, w - inset, h - inset);
        float off = elevation * 0.55f;

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // Concave base
        p.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom,
            KazUi.mix(surface, dark, 0.38f), KazUi.mix(surface, light, 0.40f), Shader.TileMode.CLAMP));
        c.drawRoundRect(r, radius, radius, p);
        p.setShader(null);

        // Inner shadows: a big frame with a rounded hole, shifted and blurred
        Path frame = new Path();
        frame.setFillType(Path.FillType.EVEN_ODD);
        float pad = elevation * 5f;
        frame.addRect(r.left - pad, r.top - pad, r.right + pad, r.bottom + pad, Path.Direction.CW);
        frame.addRoundRect(r, radius, radius, Path.Direction.CW);

        p.setMaskFilter(new BlurMaskFilter(Math.max(1f, elevation), BlurMaskFilter.Blur.NORMAL));
        p.setColor(dark);
        c.save();
        c.translate(off, off);
        c.drawPath(frame, p);
        c.restore();

        p.setColor(light);
        c.save();
        c.translate(-off, -off);
        c.drawPath(frame, p);
        c.restore();

        // Wipe everything outside the rounded rectangle (antialiased edge, applied once)
        Paint clear = new Paint(Paint.ANTI_ALIAS_FLAG);
        clear.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
        Path outside = new Path();
        outside.setFillType(Path.FillType.INVERSE_EVEN_ODD);
        outside.addRoundRect(r, radius, radius, Path.Direction.CW);
        c.drawPath(outside, clear);
        return bmp;
    }

    @Override
    public void setAlpha(int alpha) {
        // not supported
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {
        // not supported
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
