package kz.qoba.NovaEvents.listeners;

import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.block.Block;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import java.util.List;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.EventPriority;
import org.bukkit.event.EventHandler;
import kz.qoba.NovaEvents.models.ActiveEventData;
import org.bukkit.entity.HumanEntity;
import org.bukkit.event.inventory.InventoryClickEvent;
import kz.qoba.NovaEvents.models.EventModel;
import org.bukkit.inventory.Inventory;
import org.bukkit.entity.Player;
import java.util.HashMap;
import java.util.UUID;
import java.util.Map;
import kz.qoba.NovaEvents.gui.LootGUI;
import kz.qoba.NovaEvents.NovaEvents;
import org.bukkit.event.Listener;

public class PlayerListener implements Listener
{
    private final NovaEvents plugin;
    private final LootGUI lootGUI;
    private final Map<UUID, String> openGUI;

    public PlayerListener(final NovaEvents plugin) {
        this.openGUI = new HashMap<UUID, String>();
        this.plugin = plugin;
        this.lootGUI = new LootGUI(plugin);
    }

    public LootGUI getLootGUI() {
        return this.lootGUI;
    }

    public void openLootGUI(final Player player, final EventModel model) {
        final Inventory inv = this.lootGUI.buildLootGUI(model);
        this.openGUI.put(player.getUniqueId(), "loot_admin:" + model.getId());
        player.openInventory(inv);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryClick(final InventoryClickEvent event) {
        final HumanEntity var3 = event.getWhoClicked();
        if (var3 instanceof final Player player) {
            final UUID var4 = player.getUniqueId();
            final String gui = this.openGUI.get(var4);
            if (gui != null) {
                if (!gui.startsWith("loot_admin:") && gui.startsWith("shulker:")) {
                    final String eventId = gui.substring("shulker:".length());
                    final EventModel model = this.plugin.getEventManager().getEvent(eventId);
                    if (model == null) {
                        event.setCancelled(true);
                        return;
                    }
                    final ActiveEventData data = model.getActiveData();
                    if (data == null || !data.isShulkerUnlocked()) {
                        event.setCancelled(true);
                        player.sendMessage(this.plugin.getConfigManager().getMessage("shulker-locked"));
                        return;
                    }
                    if (event.getRawSlot() >= event.getInventory().getSize()) {
                        if (event.isShiftClick()) {
                            event.setCancelled(true);
                        }
                        return;
                    }
                    if (event.getCursor() != null && !event.getCursor().getType().isAir()) {
                        event.setCancelled(true);
                    }
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryDrag(final InventoryDragEvent event) {
        final HumanEntity var3 = event.getWhoClicked();
        if (var3 instanceof final Player player) {
            final UUID var4 = player.getUniqueId();
            final String gui = this.openGUI.get(var4);
            if (gui != null) {
                if (gui.startsWith("shulker:")) {
                    for (final int slot : event.getRawSlots()) {
                        if (slot < event.getInventory().getSize()) {
                            event.setCancelled(true);
                        }
                    }
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClose(final InventoryCloseEvent event) {
        final HumanEntity var3 = event.getPlayer();
        if (var3 instanceof final Player player) {
            final UUID var4 = player.getUniqueId();
            final String gui = this.openGUI.get(var4);
            if (gui != null) {
                if (gui.startsWith("loot_admin:")) {
                    final String eventId = gui.substring("loot_admin:".length());
                    final EventModel model = this.plugin.getEventManager().getEvent(eventId);
                    if (model != null) {
                        final List<ItemStack> loot = this.lootGUI.extractLoot(event.getInventory());
                        model.setLoot(loot);
                        this.plugin.getConfigManager().saveEvent(model);
                        player.sendMessage(this.plugin.getConfigManager().getMessage("loot-saved"));
                    }
                }
                if (gui.startsWith("shulker:")) {
                    this.plugin.getEventManager().unregisterShulkerViewer(var4);
                }
                this.openGUI.remove(var4);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBreak(final BlockBreakEvent event) {
        if (!this.plugin.getEventManager().canModifyProtectedZone(event.getPlayer(), event.getBlock().getLocation())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockPlace(final BlockPlaceEvent event) {
        if (!this.plugin.getEventManager().canModifyProtectedZone(event.getPlayer(), event.getBlockPlaced().getLocation())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerInteract(final PlayerInteractEvent event) {
        final Block clickedBlock = event.getClickedBlock();
        if (clickedBlock != null) {
            final EventModel model = this.plugin.getEventManager().getEventByShulkerBlock(clickedBlock);
            if (model != null) {
                event.setCancelled(true);
                final Player player = event.getPlayer();
                if (model.getState() == EventModel.EventState.OPEN) {
                    final boolean opened = this.plugin.getEventManager().openShulkerForPlayer(player, model);
                    if (opened) {
                        this.plugin.getEventManager().registerShulkerViewer(player.getUniqueId());
                        this.openGUI.put(player.getUniqueId(), "shulker:" + model.getId());
                        player.sendMessage(this.plugin.getConfigManager().getMessage("shulker-opened"));
                    }
                } else if (model.getState() == EventModel.EventState.ACTIVE) {
                    player.sendMessage(this.plugin.getConfigManager().getMessage("shulker-locked"));
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityExplode(final EntityExplodeEvent event) {
        event.blockList().removeIf(block -> this.plugin.getEventManager().getProtectedEventAt(block.getLocation()) != null);
    }

    @EventHandler
    public void onPlayerJoin(final PlayerJoinEvent event) {
        final Player player = event.getPlayer();
        for (final EventModel model : this.plugin.getEventManager().getEvents().values()) {
            final ActiveEventData data = model.getActiveData();
            if (data == null) {
                continue;
            }
            if (model.getState() == EventModel.EventState.ACTIVE) {
                data.getBossBar().addPlayer(player);
            }
            // Re-check the event hologram on every join/reconnect. If the
            // chunk was unloaded while no one was online and the armor
            // stands were lost, this respawns them so the hologram does
            // not stay missing after a reconnect.
            if (model.getState() == EventModel.EventState.ACTIVE || model.getState() == EventModel.EventState.OPEN) {
                this.plugin.getHologramManager().ensureHologram(model, data);
            }
        }
    }
}
