package com.termux.app.kaz;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.view.animation.DecelerateInterpolator;

/**
 * Background of the swipe-right panel: icy gradient, icicles hanging from the top edge, a soft
 * snow-drift along the bottom and a frosty rim on the right edge. Colours cross-fade when the
 * theme changes.
 */
public class KazPanelBackground extends Drawable {

    private final float d;
    private final ArgbEvaluator argb = new ArgbEvaluator();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path icicles = new Path();
    private final Path drift = new Path();
    private final Path driftShadow = new Path();

    private int top = 0xFFEEF7FE;
    private int bottom = 0xFFD5E8F7;
    private int frost = 0xFFFFFFFF;
    private int rim = 0xFF7FD0FF;
    private boolean dark = false;

    private ValueAnimator anim;

    public KazPanelBackground(float density) {
        this.d = density;
    }

    public void setTheme(KazTheme t, boolean animate) {
        if (anim != null) anim.cancel();
        final int fromTop = top, fromBottom = bottom, fromFrost = frost, fromRim = rim;
        final int toTop = t.bgTop, toBottom = t.bgBottom, toFrost = t.frost, toRim = t.accent2;
        dark = t.dark;
        if (!animate) {
            top = toTop;
            bottom = toBottom;
            frost = toFrost;
            rim = toRim;
            invalidateSelf();
            return;
        }
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(380);
        anim.setInterpolator(new DecelerateInterpolator());
        anim.addUpdateListener(a -> {
            float f = (Float) a.getAnimatedValue();
            top = (Integer) argb.evaluate(f, fromTop, toTop);
            bottom = (Integer) argb.evaluate(f, fromBottom, toBottom);
            frost = (Integer) argb.evaluate(f, fromFrost, toFrost);
            rim = (Integer) argb.evaluate(f, fromRim, toRim);
            invalidateSelf();
        });
        anim.start();
    }

    @Override
    protected void onBoundsChange(Rect b) {
        buildShapes(b.width(), b.height());
    }

    private void buildShapes(int w, int h) {
        // Icicles
        icicles.reset();
        float step = 17f * d;
        float x = -4f * d;
        int k = 0;
        while (x < w) {
            float len = (7f + ((k * 5) % 7) * 3.4f + (k % 2) * 3f) * d;
            icicles.moveTo(x, 0);
            icicles.lineTo(x + step, 0);
            icicles.quadTo(x + step * 0.56f, len * 0.55f, x + step * 0.5f, len);
            icicles.quadTo(x + step * 0.44f, len * 0.55f, x, 0);
            icicles.close();
            x += step;
            k++;
        }

        // Snow drift
        float base = h - 12f * d;
        drift.reset();
        drift.moveTo(0, h);
        drift.lineTo(0, base);
        int segs = 5;
        float sw = w / (float) segs;
        for (int i = 0; i < segs; i++) {
            float peak = (i % 2 == 0) ? -9f * d : 5f * d;
            drift.quadTo(sw * i + sw * 0.5f, base + peak, sw * (i + 1), base - ((i % 2 == 0) ? 1f : -1f) * 2f * d);
        }
        drift.lineTo(w, h);
        drift.close();
        driftShadow.set(drift);
        driftShadow.offset(0, -2f * d);
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        int w = b.width();
        int h = b.height();
        if (w <= 0 || h <= 0) return;
        c.save();
        c.translate(b.left, b.top);

        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(0, 0, 0, h, top, bottom, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, paint);
        paint.setShader(null);

        // Drift (behind the controls, so it stays subtle on dark themes)
        paint.setColor(KazUi.withAlpha(dark ? 0xFF000000 : 0xFF7FA6C8, dark ? 60 : 38));
        c.drawPath(driftShadow, paint);
        paint.setColor(KazUi.withAlpha(frost, dark ? 34 : 235));
        c.drawPath(drift, paint);

        // Icicles
        paint.setColor(KazUi.withAlpha(frost, dark ? 70 : 245));
        c.drawPath(icicles, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1f * d);
        paint.setColor(KazUi.withAlpha(rim, dark ? 120 : 150));
        c.drawPath(icicles, paint);

        // Frosty rim on the right edge
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(w - 4f * d, 0, w, 0,
            KazUi.withAlpha(rim, 0), KazUi.withAlpha(rim, dark ? 150 : 190), Shader.TileMode.CLAMP));
        c.drawRect(w - 4f * d, 0, w, h, paint);
        paint.setShader(null);

        c.restore();
    }

    @Override
    public void setAlpha(int alpha) {
        // not supported
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {
        // not supported
    }

    @Override
    public int getOpacity() {
        return PixelFormat.OPAQUE;
    }
}
