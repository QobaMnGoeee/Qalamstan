package kz.qoba.NovaEvents.models;

import org.bukkit.Color;
import java.util.Locale;
import org.bukkit.Particle;
import org.bukkit.configuration.ConfigurationSection;

public class EventParticleConfig
{
    private final String typeName;
    private final int count;
    private final double speed;
    private final double spread;
    private final int intervalTicks;
    private final int offsetY;
    private final boolean enabled;
    private final String dustColor;
    private final float dustSize;
    
    public EventParticleConfig(final String typeName, final int count, final double speed, final double spread, final int intervalTicks, final int offsetY, final boolean enabled, final String dustColor, final float dustSize) {
        this.typeName = typeName;
        this.count = Math.max(1, count);
        this.speed = speed;
        this.spread = Math.max(0.0, spread);
        this.intervalTicks = Math.max(1, intervalTicks);
        this.offsetY = offsetY;
        this.enabled = enabled;
        this.dustColor = dustColor;
        this.dustSize = ((dustSize <= 0.0f) ? 1.0f : dustSize);
    }
    
    public static EventParticleConfig fromSection(final ConfigurationSection section) {
        final String type = section.getString("type", "FLAME");
        final int count = section.getInt("count", 3);
        final double speed = section.getDouble("speed", 0.02);
        final double spread = section.getDouble("spread", 1.5);
        final int intervalTicks = section.getInt("interval-ticks", section.getInt("interval", 10));
        final int offsetY = section.getInt("offset-y", 0);
        final boolean enabled = section.getBoolean("enabled", true);
        final String dustColor = section.getString("dust-color", section.getString("color"));
        final float dustSize = (float)section.getDouble("dust-size", 1.0);
        return new EventParticleConfig(type, count, speed, spread, intervalTicks, offsetY, enabled, dustColor, dustSize);
    }
    
    public String getTypeName() {
        return this.typeName;
    }
    
    public int getCount() {
        return this.count;
    }
    
    public double getSpeed() {
        return this.speed;
    }
    
    public double getSpread() {
        return this.spread;
    }
    
    public int getIntervalTicks() {
        return this.intervalTicks;
    }
    
    public int getOffsetY() {
        return this.offsetY;
    }
    
    public boolean isEnabled() {
        return this.enabled;
    }
    
    public String getDustColor() {
        return this.dustColor;
    }
    
    public float getDustSize() {
        return this.dustSize;
    }
    
    public Particle resolveParticle() {
        if (this.typeName != null && !this.typeName.isBlank()) {
            try {
                return Particle.valueOf(this.typeName.trim().toUpperCase(Locale.ROOT));
            }
            catch (final IllegalArgumentException var2) {
                return null;
            }
        }
        return null;
    }
    
    public Object resolveParticleData(final Particle particle) {
        if (particle == null || this.dustColor == null || this.dustColor.isBlank()) {
            return null;
        }
        if (particle != Particle.DUST && particle != Particle.DUST_COLOR_TRANSITION) {
            return null;
        }
        final Color color = parseColor(this.dustColor);
        return (color == null) ? null : new Particle.DustOptions(color, this.dustSize);
    }
    
    private static Color parseColor(final String raw) {
        String value = raw.trim();
        if (value.startsWith("#")) {
            value = value.substring(1);
        }
        try {
            if (value.length() == 6) {
                final int rgb = Integer.parseInt(value, 16);
                return Color.fromRGB(rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF);
            }
        }
        catch (final NumberFormatException ex) {}
        return null;
    }
}
