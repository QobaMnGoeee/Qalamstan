package com.termux.app.kaz;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

import java.util.Random;

/**
 * Animated falling snow with twinkling ornaments (4-point sparkles and hollow diamonds, like
 * the reference GUI art).
 *
 * <ul>
 *   <li>{@link #MODE_PANEL}: snow + sparkles, used behind the swipe-right panel.</li>
 *   <li>{@link #MODE_OVERLAY}: lighter snow + a faint frosty edge with tiny icicles, drawn over
 *       the terminal. It never handles touches, so the terminal stays fully usable.</li>
 * </ul>
 */
public class SnowView extends View {

    public static final int MODE_PANEL = 0;
    public static final int MODE_OVERLAY = 1;

    private static final class Flake {
        float x, y, r, speed, phase, drift, alpha;
    }

    private static final class Sparkle {
        float x, y, size, phase, rate;
        boolean diamond;
    }

    private int mode = MODE_PANEL;
    private final Random rnd = new Random(7);
    private Flake[] flakes = new Flake[0];
    private Sparkle[] sparkles = new Sparkle[0];

    private final Paint flakePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint haloPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sparkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint frostPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path sparkPath = new Path();
    private final Path iciclePath = new Path();

    private int flakeColor = 0xFFFFFFFF;
    private int haloColor = 0xFF7FD0FF;
    private int sparkleColor = 0xFFFFFFFF;
    private int frostColor = 0xFFFFFFFF;
    private boolean lightBackdrop = true;

    private float wind;          // px/s, decays to 0
    private float time;          // seconds
    private long lastNanos;
    private boolean enabled = true;
    private boolean running;
    private boolean attached;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            long now = System.nanoTime();
            float dt = lastNanos == 0 ? 0.016f : Math.min(0.05f, (now - lastNanos) / 1e9f);
            lastNanos = now;
            step(dt);
            invalidate();
            postOnAnimation(this);
        }
    };

    public SnowView(Context context) {
        this(context, null);
    }

    public SnowView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setWillNotDraw(false);
        setClickable(false);
        setFocusable(false);
        sparkPaint.setStyle(Paint.Style.STROKE);
        sparkPaint.setStrokeCap(Paint.Cap.ROUND);
        sparkPaint.setStrokeJoin(Paint.Join.ROUND);
        frostPaint.setStyle(Paint.Style.FILL);
    }

    public void setMode(int mode) {
        this.mode = mode;
        rebuild();
    }

    public void applyPalette(KazTheme t) {
        lightBackdrop = !t.dark;
        flakeColor = 0xFFFFFFFF;
        haloColor = t.dark ? 0xFFBFE6FF : t.accent2;
        sparkleColor = t.dark ? KazUi.mix(t.accent2, 0xFFFFFFFF, 0.4f) : KazUi.mix(t.accent, 0xFFFFFFFF, 0.25f);
        frostColor = t.frost;
        invalidate();
    }

    /** Enables/disables drawing and animation entirely (used by the overlay toggle). */
    public void setSnowEnabled(boolean on) {
        enabled = on;
        setVisibility(on ? VISIBLE : GONE);
        updateRunning();
    }

    /** Sets the animation to run only while it makes sense (drawer open / activity visible). */
    public void setActive(boolean active) {
        if (active) lastNanos = 0;
        this.activeFlag = active;
        updateRunning();
    }

    private boolean activeFlag = true;

    /** Gust of wind. Positive pushes flakes to the right. */
    public void gust(float pxPerSecond) {
        wind += pxPerSecond;
        float max = 900f;
        if (wind > max) wind = max;
        if (wind < -max) wind = -max;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attached = true;
        updateRunning();
    }

    @Override
    protected void onDetachedFromWindow() {
        attached = false;
        updateRunning();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        updateRunning();
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        updateRunning();
    }

    private void updateRunning() {
        boolean should = enabled && activeFlag && attached
            && getWindowVisibility() == VISIBLE && getVisibility() == VISIBLE;
        if (should && !running) {
            running = true;
            lastNanos = 0;
            postOnAnimation(tick);
        } else if (!should && running) {
            running = false;
            removeCallbacks(tick);
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        rebuild();
    }

    private void rebuild() {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;
        float d = getResources().getDisplayMetrics().density;

        int count = mode == MODE_PANEL ? 46 : 26;
        flakes = new Flake[count];
        for (int i = 0; i < count; i++) {
            Flake f = new Flake();
            respawn(f, w, h, d, true);
            flakes[i] = f;
        }

        if (mode == MODE_PANEL) {
            sparkles = new Sparkle[16];
            for (int i = 0; i < sparkles.length; i++) {
                Sparkle s = new Sparkle();
                s.x = rnd.nextFloat() * w;
                s.y = rnd.nextFloat() * h;
                s.size = (4f + rnd.nextFloat() * 6f) * d;
                s.phase = rnd.nextFloat() * 6.28f;
                s.rate = 0.8f + rnd.nextFloat() * 1.6f;
                s.diamond = (i % 3 == 0);
                sparkles[i] = s;
            }
        } else {
            sparkles = new Sparkle[0];
        }

        // Icicle teeth along the top edge (overlay mode)
        iciclePath.reset();
        float step = 13f * d;
        float x = 0;
        int k = 0;
        while (x < w) {
            float len = (4f + ((k * 7) % 5) * 2.4f + (k % 3) * 1.5f) * d;
            iciclePath.moveTo(x, 0);
            iciclePath.lineTo(x + step, 0);
            iciclePath.lineTo(x + step * 0.5f, len);
            iciclePath.close();
            x += step;
            k++;
        }
    }

    private void respawn(Flake f, int w, int h, float d, boolean anywhere) {
        f.x = rnd.nextFloat() * w;
        f.y = anywhere ? rnd.nextFloat() * h : -rnd.nextFloat() * 20f * d;
        float depth = rnd.nextFloat();                      // 0 far .. 1 near
        f.r = (1.1f + depth * 2.6f) * d * (mode == MODE_OVERLAY ? 0.85f : 1f);
        f.speed = (14f + depth * 46f) * d;
        f.phase = rnd.nextFloat() * 6.28f;
        f.drift = (6f + rnd.nextFloat() * 14f) * d;
        f.alpha = mode == MODE_OVERLAY ? 0.45f + depth * 0.4f : 0.55f + depth * 0.45f;
    }

    private void step(float dt) {
        time += dt;
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;
        float d = getResources().getDisplayMetrics().density;
        wind *= (float) Math.pow(0.12, dt);   // quick decay
        if (Math.abs(wind) < 1f) wind = 0f;
        for (Flake f : flakes) {
            f.y += f.speed * dt;
            f.x += (float) Math.sin(time * 0.9f + f.phase) * f.drift * dt + wind * dt * (f.r / (3f * d));
            if (f.y - f.r > h) respawn(f, w, h, d, false);
            if (f.x < -f.r * 2) f.x = w + f.r;
            if (f.x > w + f.r * 2) f.x = -f.r;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth();
        int h = getHeight();
        float d = getResources().getDisplayMetrics().density;

        if (mode == MODE_OVERLAY) drawFrostEdge(c, w, d);

        for (Sparkle s : sparkles) drawSparkle(c, s, d);

        for (Flake f : flakes) {
            int a = Math.round(255 * f.alpha);
            if (lightBackdrop) {
                haloPaint.setColor(KazUi.withAlpha(haloColor, Math.round(a * 0.40f)));
                c.drawCircle(f.x, f.y, f.r * 1.7f, haloPaint);
            }
            flakePaint.setColor(KazUi.withAlpha(flakeColor, a));
            c.drawCircle(f.x, f.y, f.r, flakePaint);
        }
    }

    private void drawFrostEdge(Canvas c, int w, float d) {
        float band = 16f * d;
        frostPaint.setShader(new LinearGradient(0, 0, 0, band,
            KazUi.withAlpha(frostColor, lightBackdrop ? 120 : 70), KazUi.withAlpha(frostColor, 0), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, band, frostPaint);
        frostPaint.setShader(null);
        frostPaint.setColor(KazUi.withAlpha(frostColor, lightBackdrop ? 150 : 90));
        c.drawPath(iciclePath, frostPaint);
    }

    private void drawSparkle(Canvas c, Sparkle s, float d) {
        float tw = 0.5f + 0.5f * (float) Math.sin(time * s.rate + s.phase);
        int a = Math.round(255 * (0.25f + 0.75f * tw));
        sparkPaint.setColor(KazUi.withAlpha(sparkleColor, a));
        sparkPaint.setStrokeWidth(1.2f * d);
        float r = s.size * (0.8f + 0.2f * tw);
        sparkPath.reset();
        if (s.diamond) {
            sparkPaint.setStyle(Paint.Style.STROKE);
            sparkPath.moveTo(s.x, s.y - r);
            sparkPath.lineTo(s.x + r * 0.62f, s.y);
            sparkPath.lineTo(s.x, s.y + r);
            sparkPath.lineTo(s.x - r * 0.62f, s.y);
            sparkPath.close();
        } else {
            sparkPaint.setStyle(Paint.Style.FILL);
            float n = r * 0.22f;
            sparkPath.moveTo(s.x, s.y - r);
            sparkPath.quadTo(s.x + n, s.y - n, s.x + r, s.y);
            sparkPath.quadTo(s.x + n, s.y + n, s.x, s.y + r);
            sparkPath.quadTo(s.x - n, s.y + n, s.x - r, s.y);
            sparkPath.quadTo(s.x - n, s.y - n, s.x, s.y - r);
            sparkPath.close();
        }
        c.drawPath(sparkPath, sparkPaint);
    }
}
