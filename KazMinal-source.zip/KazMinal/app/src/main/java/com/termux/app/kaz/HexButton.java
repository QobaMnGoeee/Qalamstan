package com.termux.app.kaz;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/**
 * Faceted hexagonal "ice gem" button, in the spirit of the pixel-art menu buttons from the
 * reference images, but drawn as smooth vectors. Carries one of a few built-in glyphs.
 */
public class HexButton extends View {

    public static final int ICON_GEAR = 0;
    public static final int ICON_SNOWFLAKE = 1;
    public static final int ICON_CHECK = 2;

    private int icon = ICON_GEAR;
    private int accent = 0xFF2F8BE6;
    private int accent2 = 0xFF7FD0FF;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint facet = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glyph = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path hex = new Path();
    private final Path tri = new Path();
    private final float[] vx = new float[6];
    private final float[] vy = new float[6];

    public HexButton(Context context) {
        this(context, null);
    }

    public HexButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        glyph.setStyle(Paint.Style.STROKE);
        glyph.setStrokeCap(Paint.Cap.ROUND);
        glyph.setStrokeJoin(Paint.Join.ROUND);
        setClickable(true);
        setFocusable(true);
    }

    public void setIcon(int icon) {
        this.icon = icon;
        invalidate();
    }

    public void applyPalette(KazTheme t) {
        accent = t.accent;
        accent2 = t.accent2;
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (isClickable()) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    animate().scaleX(1f).scaleY(1f).setDuration(180).setInterpolator(new DecelerateInterpolator()).start();
                    break;
                default:
                    break;
            }
        }
        return super.onTouchEvent(e);
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int def = KazUi.dp(getContext(), 48);
        setMeasuredDimension(resolveSize(def, wSpec), resolveSize(def, hSpec));
    }

    @Override
    protected void onDraw(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float pad = 3f * d;
        float r = Math.min(getWidth(), getHeight()) / 2f - pad;
        if (r <= 0) return;

        buildHex(cx, cy, r);

        // Drop shadow
        fill.setShader(null);
        fill.setColor(KazUi.withAlpha(KazUi.darken(accent, 0.6f), 70));
        c.save();
        c.translate(0, 2f * d);
        c.drawPath(hex, fill);
        c.restore();

        // Body
        fill.setShader(new LinearGradient(cx, cy - r, cx, cy + r,
            KazUi.lighten(accent2, 0.45f), accent, Shader.TileMode.CLAMP));
        c.drawPath(hex, fill);
        fill.setShader(null);

        // Facets: lit upper-left, shaded lower-right
        for (int i = 0; i < 6; i++) {
            int j = (i + 1) % 6;
            tri.reset();
            tri.moveTo(cx, cy);
            tri.lineTo(vx[i], vy[i]);
            tri.lineTo(vx[j], vy[j]);
            tri.close();
            boolean lit = (i == 4 || i == 5 || i == 0);
            facet.setColor(lit ? 0x38FFFFFF : 0x26000000);
            c.drawPath(tri, facet);
        }

        // Outline + inner bevel line
        stroke.setStrokeWidth(2f * d);
        stroke.setColor(KazUi.darken(accent, 0.55f));
        c.drawPath(hex, stroke);

        buildHex(cx, cy, r * 0.86f);
        stroke.setStrokeWidth(1f * d);
        stroke.setColor(0x80FFFFFF);
        c.drawPath(hex, stroke);

        drawGlyph(c, cx, cy, r, d);
    }

    private void buildHex(float cx, float cy, float r) {
        hex.reset();
        for (int i = 0; i < 6; i++) {
            double a = Math.toRadians(-90 + 60 * i);
            vx[i] = cx + (float) (r * Math.cos(a));
            vy[i] = cy + (float) (r * Math.sin(a));
            if (i == 0) hex.moveTo(vx[i], vy[i]); else hex.lineTo(vx[i], vy[i]);
        }
        hex.close();
    }

    private void drawGlyph(Canvas c, float cx, float cy, float r, float d) {
        int shadow = KazUi.withAlpha(KazUi.darken(accent, 0.6f), 140);
        glyph.setStrokeWidth(Math.max(1.6f * d, r * 0.11f));
        // shadow pass then white pass
        for (int pass = 0; pass < 2; pass++) {
            glyph.setColor(pass == 0 ? shadow : 0xFFFFFFFF);
            float oy = pass == 0 ? 1.2f * d : 0f;
            c.save();
            c.translate(0, oy);
            switch (icon) {
                case ICON_SNOWFLAKE:
                    drawSnowflake(c, cx, cy, r * 0.62f);
                    break;
                case ICON_CHECK:
                    drawCheck(c, cx, cy, r);
                    break;
                default:
                    drawGear(c, cx, cy, r);
                    break;
            }
            c.restore();
        }
    }

    private void drawGear(Canvas c, float cx, float cy, float r) {
        glyph.setStyle(Paint.Style.STROKE);
        c.drawCircle(cx, cy, r * 0.30f, glyph);
        float inner = r * 0.44f;
        float outer = r * 0.60f;
        for (int i = 0; i < 8; i++) {
            double a = Math.toRadians(45 * i);
            float cos = (float) Math.cos(a);
            float sin = (float) Math.sin(a);
            c.drawLine(cx + cos * inner, cy + sin * inner, cx + cos * outer, cy + sin * outer, glyph);
        }
    }

    private void drawCheck(Canvas c, float cx, float cy, float r) {
        Path p = new Path();
        p.moveTo(cx - r * 0.34f, cy + r * 0.02f);
        p.lineTo(cx - r * 0.08f, cy + r * 0.28f);
        p.lineTo(cx + r * 0.38f, cy - r * 0.26f);
        c.drawPath(p, glyph);
    }

    private void drawSnowflake(Canvas c, float cx, float cy, float len) {
        for (int i = 0; i < 6; i++) {
            double a = Math.toRadians(60 * i - 90);
            float cos = (float) Math.cos(a);
            float sin = (float) Math.sin(a);
            float ex = cx + cos * len;
            float ey = cy + sin * len;
            c.drawLine(cx, cy, ex, ey, glyph);
            // little V-branch two-thirds out
            float bx = cx + cos * len * 0.62f;
            float by = cy + sin * len * 0.62f;
            for (int s = -1; s <= 1; s += 2) {
                double ba = a + Math.toRadians(55 * s);
                c.drawLine(bx, by, bx + (float) Math.cos(ba) * len * 0.30f, by + (float) Math.sin(ba) * len * 0.30f, glyph);
            }
        }
    }
}
