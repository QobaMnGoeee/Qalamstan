package com.termux.app.kaz;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** Tiny terminal window rendered with a theme's real terminal colours. */
public class ThemePreview extends View {

    private final KazTheme theme;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    public ThemePreview(Context context, KazTheme theme) {
        super(context);
        this.theme = theme;
        paint.setTypeface(Typeface.MONOSPACE);
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        setMeasuredDimension(KazUi.dp(getContext(), 92), KazUi.dp(getContext(), 66));
    }

    @Override
    protected void onDraw(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        float w = getWidth();
        float h = getHeight();
        float rad = 10f * d;

        // window
        rect.set(0, 0, w, h);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(theme.termBg);
        c.drawRoundRect(rect, rad, rad, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.2f * d);
        paint.setColor(KazUi.withAlpha(theme.accent, 120));
        rect.inset(0.6f * d, 0.6f * d);
        c.drawRoundRect(rect, rad, rad, paint);

        // title dots
        paint.setStyle(Paint.Style.FILL);
        float dotR = 2.2f * d;
        float dy = 9f * d;
        paint.setColor(theme.ansi[9]);
        c.drawCircle(10f * d, dy, dotR, paint);
        paint.setColor(theme.ansi[11]);
        c.drawCircle(18f * d, dy, dotR, paint);
        paint.setColor(theme.ansi[10]);
        c.drawCircle(26f * d, dy, dotR, paint);

        // text lines
        paint.setTextSize(9f * d);
        float x = 8f * d;
        float y = 27f * d;
        float adv = paint.measureText("0");

        paint.setColor(theme.ansi[10]);
        c.drawText("~$", x, y, paint);
        paint.setColor(theme.termFg);
        c.drawText("ls", x + adv * 3, y, paint);

        y += 12f * d;
        paint.setColor(theme.ansi[12]);
        c.drawText("қыс", x, y, paint);
        paint.setColor(theme.ansi[14]);
        c.drawText("kaz", x + adv * 4, y, paint);
        paint.setColor(theme.ansi[13]);
        c.drawText("ӘІ", x + adv * 8, y, paint);

        y += 12f * d;
        paint.setColor(theme.ansi[10]);
        c.drawText("~$", x, y, paint);
        paint.setColor(theme.termCursor);
        rect.set(x + adv * 3, y - 8f * d, x + adv * 3 + adv * 0.9f, y + 1.5f * d);
        c.drawRect(rect, paint);
    }
}
