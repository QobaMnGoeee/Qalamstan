package kz.qoba.NovaEvents.utils;

import java.util.regex.Matcher;
import net.md_5.bungee.api.ChatColor;
import java.util.regex.Pattern;

public class ColorUtil
{
    private static final Pattern HEX_PATTERN;
    private static final Pattern AMPERSAND_PATTERN;
    
    public static String colorize(String text) {
        if (text == null) {
            return "";
        }
        final Matcher hexMatcher = ColorUtil.HEX_PATTERN.matcher(text);
        final StringBuffer sb = new StringBuffer();
        while (hexMatcher.find()) {
            final String hex = hexMatcher.group(1);
            hexMatcher.appendReplacement(sb, ChatColor.of("#" + hex).toString());
        }
        hexMatcher.appendTail(sb);
        text = sb.toString();
        text = ChatColor.translateAlternateColorCodes('&', text);
        return text;
    }
    
    public static String strip(final String text) {
        return (text == null) ? "" : ChatColor.stripColor(colorize(text));
    }
    
    static {
        HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
        AMPERSAND_PATTERN = Pattern.compile("&([0-9a-fk-orA-FK-OR])");
    }
}
