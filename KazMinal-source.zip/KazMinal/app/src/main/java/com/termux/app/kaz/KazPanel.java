package com.termux.app.kaz;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.termux.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Controller of the winter swipe-right panel. It owns the three tabs (sessions / themes / fonts),
 * builds the theme and font cards, and applies the selected theme to the panel, the terminal
 * toolbar and (through {@link Host}) the terminal itself.
 */
public final class KazPanel {

    /** What the panel needs from the surrounding activity. */
    public interface Host {
        /** Re-reads the selected theme/font and applies them to the running terminal. */
        void reloadTerminalStyle();

        /** Styles the extra-keys toolbar to match the theme. */
        void styleToolbar(KazTheme theme);

        /** Re-binds the session list rows (theme colours changed). */
        void refreshSessionList();
    }

    private static final int PAGE_SESSIONS = 0;
    private static final int PAGE_THEMES = 1;
    private static final int PAGE_FONTS = 2;

    private final Activity act;
    private final Host host;
    private final float d;

    private KazPanelBackground background;
    private SnowView snowPanel;
    private SnowView snowOverlay;
    private TextView title;
    private TextView subtitle;
    private HexButton logo;
    private HexButton settings;
    private NeuButton[] tabs;
    private View[] pages;
    private NeuButton keyboardButton;
    private NeuButton newSessionButton;
    private NeuButton snowToggle;
    private TextView themesLabel;
    private TextView fontsLabel;

    private final List<Card> themeCards = new ArrayList<>();
    private final List<Card> fontCards = new ArrayList<>();

    private int page = PAGE_SESSIONS;
    private float lastSlide = 0f;
    private KazTheme current;

    public KazPanel(Activity activity, Host host) {
        this.act = activity;
        this.host = host;
        this.d = activity.getResources().getDisplayMetrics().density;
    }

    public KazTheme getTheme() {
        return current;
    }

    // ------------------------------------------------------------------------------------------
    // Setup
    // ------------------------------------------------------------------------------------------

    public void attach(View drawerRoot, SnowView overlay) {
        background = new KazPanelBackground(d);
        drawerRoot.setBackground(background);

        snowPanel = act.findViewById(R.id.kaz_snow_panel);
        snowPanel.setMode(SnowView.MODE_PANEL);
        snowPanel.setActive(false);
        snowOverlay = overlay;
        snowOverlay.setMode(SnowView.MODE_OVERLAY);

        title = act.findViewById(R.id.kaz_title);
        subtitle = act.findViewById(R.id.kaz_subtitle);
        logo = act.findViewById(R.id.kaz_logo);
        logo.setIcon(HexButton.ICON_SNOWFLAKE);
        settings = act.findViewById(R.id.settings_button);
        settings.setIcon(HexButton.ICON_GEAR);

        keyboardButton = act.findViewById(R.id.toggle_keyboard_button);
        newSessionButton = act.findViewById(R.id.new_session_button);

        tabs = new NeuButton[]{
            act.findViewById(R.id.kaz_tab_sessions),
            act.findViewById(R.id.kaz_tab_themes),
            act.findViewById(R.id.kaz_tab_fonts)};
        pages = new View[]{
            act.findViewById(R.id.terminal_sessions_list),
            act.findViewById(R.id.kaz_page_themes),
            act.findViewById(R.id.kaz_page_fonts)};
        for (int i = 0; i < tabs.length; i++) {
            final int index = i;
            tabs[i].setOnClickListener(v -> showPage(index, true));
        }

        buildThemesPage((LinearLayout) act.findViewById(R.id.kaz_themes_container));
        buildFontsPage((LinearLayout) act.findViewById(R.id.kaz_fonts_container));

        snowOverlay.setSnowEnabled(KazPrefs.isSnowOverlay(act));
        applyTheme(KazPrefs.theme(act), false);
        showPage(PAGE_SESSIONS, false);
    }

    // ------------------------------------------------------------------------------------------
    // Drawer callbacks (wired by the activity)
    // ------------------------------------------------------------------------------------------

    public void onDrawerSlide(float offset) {
        if (offset > 0f) snowPanel.setActive(true);
        // Swiping the panel in/out stirs the snow
        float delta = offset - lastSlide;
        lastSlide = offset;
        snowPanel.gust(delta * 2600f);
    }

    public void onDrawerClosed() {
        lastSlide = 0f;
        snowPanel.setActive(false);
    }

    // ------------------------------------------------------------------------------------------
    // Tabs
    // ------------------------------------------------------------------------------------------

    private void showPage(int target, boolean animate) {
        int dir = target >= page ? 1 : -1;
        page = target;
        for (int i = 0; i < tabs.length; i++) {
            tabs[i].setSelectedLook(i == target, animate);
        }
        for (int i = 0; i < pages.length; i++) {
            View p = pages[i];
            p.animate().cancel();
            if (i == target) {
                p.setVisibility(View.VISIBLE);
                if (animate) {
                    p.setAlpha(0f);
                    p.setTranslationX(dir * 28f * d);
                    p.animate().alpha(1f).translationX(0f).setDuration(220)
                        .setInterpolator(new DecelerateInterpolator()).start();
                } else {
                    p.setAlpha(1f);
                    p.setTranslationX(0f);
                }
            } else {
                p.setVisibility(View.GONE);
            }
        }
        if (animate) snowPanel.gust(dir * 260f);
    }

    // ------------------------------------------------------------------------------------------
    // Themes page
    // ------------------------------------------------------------------------------------------

    private void buildThemesPage(LinearLayout box) {
        box.removeAllViews();
        themesLabel = sectionLabel(act.getString(R.string.kaz_themes_title));
        box.addView(themesLabel);

        for (int i = 0; i < KazTheme.ALL.length; i++) {
            final int index = i;
            KazTheme t = KazTheme.ALL[i];

            Card card = new Card(false);
            card.preview = new ThemePreview(act, t);
            card.title.setText(t.name);
            card.sub.setText(t.tagline);
            card.row.addView(card.preview, 0, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) card.textBox.getLayoutParams();
            lp.setMarginStart(KazUi.dp(act, 12));
            card.view.setOnClickListener(v -> selectTheme(index));
            themeCards.add(card);
            box.addView(card.view, cardParams());
        }

        snowToggle = new NeuButton(act);
        snowToggle.setOnClickListener(v -> {
            boolean on = !KazPrefs.isSnowOverlay(act);
            KazPrefs.setSnowOverlay(act, on);
            snowOverlay.setSnowEnabled(on);
            updateSnowToggle(true);
        });
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = KazUi.dp(act, 6);
        box.addView(snowToggle, tp);
    }

    private void updateSnowToggle(boolean animate) {
        boolean on = KazPrefs.isSnowOverlay(act);
        snowToggle.setText(on ? R.string.kaz_snow_on : R.string.kaz_snow_off);
        snowToggle.setSelectedLook(on, animate);
    }

    private void selectTheme(int index) {
        if (index == KazPrefs.getThemeIndex(act)) {
            snowPanel.gust(300f);
            return;
        }
        KazPrefs.setThemeIndex(act, index);
        applyTheme(KazTheme.ALL[index], true);
        host.reloadTerminalStyle();
        snowPanel.gust(620f);
    }

    // ------------------------------------------------------------------------------------------
    // Fonts page
    // ------------------------------------------------------------------------------------------

    private void buildFontsPage(LinearLayout box) {
        box.removeAllViews();
        fontsLabel = sectionLabel(act.getString(R.string.kaz_fonts_title));
        box.addView(fontsLabel);

        for (int i = 0; i < KazFont.ALL.length; i++) {
            final int index = i;
            KazFont f = KazFont.ALL[i];

            Card card = new Card(true);
            card.title.setText(f.name);
            card.sub.setText(f.note);
            card.sample.setText(R.string.kaz_font_sample);
            card.sample.setTypeface(f.load(act));
            card.view.setOnClickListener(v -> selectFont(index));
            fontCards.add(card);
            box.addView(card.view, cardParams());
        }
    }

    private void selectFont(int index) {
        if (index == KazPrefs.getFontIndex(act)) {
            snowPanel.gust(300f);
            return;
        }
        KazPrefs.setFontIndex(act, index);
        for (int i = 0; i < fontCards.size(); i++) {
            fontCards.get(i).setSelected(i == index, true);
        }
        host.reloadTerminalStyle();
        snowPanel.gust(-420f);
    }

    // ------------------------------------------------------------------------------------------
    // Theme application
    // ------------------------------------------------------------------------------------------

    public void applyTheme(KazTheme t, boolean animate) {
        current = t;
        background.setTheme(t, animate);
        snowPanel.applyPalette(t);
        snowOverlay.applyPalette(t);

        title.setTextColor(t.text);
        subtitle.setTextColor(t.subText);
        logo.applyPalette(t);
        settings.applyPalette(t);
        themesLabel.setTextColor(t.subText);
        fontsLabel.setTextColor(t.subText);

        for (int i = 0; i < tabs.length; i++) {
            tabs[i].applyPalette(t);
            tabs[i].setSelectedLook(i == page, false);
        }
        keyboardButton.applyPalette(t);
        newSessionButton.applyPalette(t);
        snowToggle.applyPalette(t);
        updateSnowToggle(false);

        int ti = KazPrefs.getThemeIndex(act);
        for (int i = 0; i < themeCards.size(); i++) {
            themeCards.get(i).applyPalette(t);
            themeCards.get(i).setSelected(i == ti, animate);
        }
        int fi = KazPrefs.getFontIndex(act);
        for (int i = 0; i < fontCards.size(); i++) {
            fontCards.get(i).applyPalette(t);
            fontCards.get(i).setSelected(i == fi, animate);
        }

        host.styleToolbar(t);
        host.refreshSessionList();
    }

    // ------------------------------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------------------------------

    private TextView sectionLabel(String text) {
        TextView tv = new TextView(act);
        tv.setText(text);
        tv.setTextSize(12f);
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tv.setLetterSpacing(0.04f);
        tv.setPadding(KazUi.dp(act, 12), KazUi.dp(act, 8), KazUi.dp(act, 12), KazUi.dp(act, 4));
        return tv;
    }

    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = KazUi.dp(act, 0);
        return lp;
    }

    /** A selectable soft-UI card (used for both themes and fonts). */
    private final class Card {
        final LinearLayout view;
        final LinearLayout row;
        final LinearLayout textBox;
        final NeuDrawable bg;
        final TextView title;
        final TextView sub;
        final TextView sample;      // fonts only
        final HexButton check;
        View preview;               // themes only
        private ValueAnimator anim;
        private boolean selected;

        Card(boolean withSample) {
            bg = new NeuDrawable(KazUi.dpf(act, 18), KazUi.dpf(act, 5));
            bg.setRing(0xFF2F8BE6, KazUi.dpf(act, 2));
            int in = bg.getInset();

            view = new LinearLayout(act);
            view.setOrientation(LinearLayout.VERTICAL);
            view.setBackground(bg);
            view.setClickable(true);
            view.setFocusable(true);
            view.setPadding(in + KazUi.dp(act, 12), in + KazUi.dp(act, 10), in + KazUi.dp(act, 12), in + KazUi.dp(act, 10));
            view.setOnTouchListener((v, e) -> {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(0.975f).scaleY(0.975f).setDuration(80).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1f).scaleY(1f).setDuration(160).start();
                        break;
                    default:
                        break;
                }
                return false;
            });

            row = new LinearLayout(act);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            view.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            textBox = new LinearLayout(act);
            textBox.setOrientation(LinearLayout.VERTICAL);
            row.addView(textBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            title = new TextView(act);
            title.setTextSize(15f);
            title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            title.setSingleLine(true);
            title.setEllipsize(TextUtils.TruncateAt.END);
            textBox.addView(title);

            sub = new TextView(act);
            sub.setTextSize(12f);
            sub.setMaxLines(2);
            sub.setEllipsize(TextUtils.TruncateAt.END);
            textBox.addView(sub);

            check = new HexButton(act);
            check.setIcon(HexButton.ICON_CHECK);
            check.setClickable(false);
            int cs = KazUi.dp(act, 26);
            row.addView(check, new LinearLayout.LayoutParams(cs, cs));

            if (withSample) {
                sample = new TextView(act);
                sample.setTextSize(15f);
                sample.setPadding(0, KazUi.dp(act, 8), 0, 0);
                view.addView(sample, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            } else {
                sample = null;
            }
        }

        void applyPalette(KazTheme t) {
            bg.setColors(t.surface, t.shadowLight, t.shadowDark);
            bg.setRing(t.accent, KazUi.dpf(act, 2));
            check.applyPalette(t);
            refreshText(t);
        }

        void refreshText(KazTheme t) {
            title.setTextColor(selected ? t.accent : t.text);
            sub.setTextColor(t.subText);
            if (sample != null) sample.setTextColor(t.text);
        }

        void setSelected(boolean sel, boolean animate) {
            boolean changed = sel != selected;
            selected = sel;
            if (current != null) refreshText(current);
            check.setVisibility(sel ? View.VISIBLE : View.INVISIBLE);
            if (anim != null) anim.cancel();
            final float to = sel ? 1f : 0f;
            if (!animate || !changed) {
                bg.setPress(to);
                bg.setRingAlpha(to);
                return;
            }
            anim = ValueAnimator.ofFloat(bg.getPress(), to);
            anim.setDuration(200);
            anim.addUpdateListener(a -> {
                float v = (Float) a.getAnimatedValue();
                bg.setPress(v);
                bg.setRingAlpha(v);
            });
            anim.start();
            if (sel) {
                check.setScaleX(0.4f);
                check.setScaleY(0.4f);
                check.animate().scaleX(1f).scaleY(1f).setDuration(260)
                    .setInterpolator(new android.view.animation.OvershootInterpolator(2.2f)).start();
            }
        }
    }
}
