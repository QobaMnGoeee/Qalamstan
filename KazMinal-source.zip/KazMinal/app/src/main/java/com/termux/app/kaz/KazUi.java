package com.termux.app.kaz;

import android.content.Context;
import android.graphics.Color;

/** Small shared helpers for the KazMinal UI code. */
public final class KazUi {

    private KazUi() {}

    public static int dp(Context c, float dp) {
        return Math.round(dp * c.getResources().getDisplayMetrics().density);
    }

    public static float dpf(Context c, float dp) {
        return dp * c.getResources().getDisplayMetrics().density;
    }

    public static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }

    /** Mixes {@code a} towards {@code b} by {@code t} (0..1). */
    public static int mix(int a, int b, float t) {
        float u = 1f - t;
        return Color.argb(
            Math.round(Color.alpha(a) * u + Color.alpha(b) * t),
            Math.round(Color.red(a) * u + Color.red(b) * t),
            Math.round(Color.green(a) * u + Color.green(b) * t),
            Math.round(Color.blue(a) * u + Color.blue(b) * t));
    }

    public static int lighten(int c, float t) {
        return mix(c, 0xFFFFFFFF, t);
    }

    public static int darken(int c, float t) {
        return mix(c, 0xFF000000, t);
    }
}
