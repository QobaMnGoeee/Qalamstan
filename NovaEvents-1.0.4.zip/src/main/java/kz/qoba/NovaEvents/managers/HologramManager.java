package kz.qoba.NovaEvents.managers;

import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Entity;
import kz.qoba.NovaEvents.utils.ColorUtil;
import org.bukkit.entity.ArmorStand;
import java.util.List;
import org.bukkit.World;
import org.bukkit.Location;
import org.bukkit.Chunk;
import java.util.UUID;
import java.util.ArrayList;
import kz.qoba.NovaEvents.models.ActiveEventData;
import kz.qoba.NovaEvents.models.EventModel;
import kz.qoba.NovaEvents.NovaEvents;

public class HologramManager
{
    private final NovaEvents plugin;
    private static final double BASE_HEIGHT = 2.0;
    private static final double LINE_GAP = 0.25;

    public HologramManager(final NovaEvents plugin) {
        this.plugin = plugin;
    }

    public void spawnHologram(final EventModel model, final ActiveEventData data) {
        final Location base = data.getShulkerLocation();
        if (base == null || base.getWorld() == null) {
            return;
        }
        final World world = base.getWorld();
        this.removeHologram(data, world);

        // Force the chunk to be loaded before spawning entities, otherwise
        // the armor stands may fail to spawn or get discarded right away
        // (this is what caused holograms to vanish when the event started
        // or after a player reconnect, since unloaded chunks were not
        // guaranteed to be loaded at this point).
        final Chunk chunk = world.getChunkAt(base);
        if (!chunk.isLoaded()) {
            chunk.load(true);
        }

        final List<UUID> ids = new ArrayList<UUID>();
        final String[] lines = this.buildLines(model, data);
        for (int i = 0; i < lines.length; ++i) {
            final double y = base.getY() + BASE_HEIGHT + (lines.length - 1 - i) * LINE_GAP;
            final Location loc = new Location(world, base.getX() + 0.5, y, base.getZ() + 0.5);
            final ArmorStand stand = this.spawnStand(world, loc, lines[i]);
            ids.add(stand.getUniqueId());
        }
        data.setHologramIds(ids);
        this.startUpdateTask(model, data);
    }

    public void updateHologram(final EventModel model, final ActiveEventData data) {
        if (data.getHologramIds() == null || data.getHologramIds().isEmpty()) {
            return;
        }
        final Location base = data.getShulkerLocation();
        if (base == null || base.getWorld() == null) {
            return;
        }
        final World world = base.getWorld();
        final String[] lines = this.buildLines(model, data);
        final List<UUID> ids = data.getHologramIds();

        // Self-healing check: if any of the hologram armor stands were
        // removed (for example after a reconnect when the chunk got
        // unloaded and the non-persistent entities disappeared), respawn
        // the whole hologram instead of silently doing nothing.
        boolean missing = false;
        for (final UUID id : ids) {
            final Entity entity = this.plugin.getServer().getEntity(id);
            if (!(entity instanceof ArmorStand)) {
                missing = true;
                break;
            }
        }
        if (missing) {
            this.spawnHologram(model, data);
            return;
        }

        for (int i = 0; i < Math.min(ids.size(), lines.length); ++i) {
            final Entity entity = this.plugin.getServer().getEntity(ids.get(i));
            if (entity instanceof ArmorStand) {
                ((ArmorStand) entity).setCustomName(ColorUtil.colorize(lines[i]));
            }
        }
    }

    // Re-checks the hologram for an active event and respawns it if any of
    // its armor stands are missing. Safe to call even if no hologram has
    // ever been spawned for this event yet.
    public void ensureHologram(final EventModel model, final ActiveEventData data) {
        if (data == null) {
            return;
        }
        final Location base = data.getShulkerLocation();
        if (base == null || base.getWorld() == null) {
            return;
        }
        final List<UUID> ids = data.getHologramIds();
        if (ids == null || ids.isEmpty()) {
            this.spawnHologram(model, data);
            return;
        }
        for (final UUID id : ids) {
            final Entity entity = this.plugin.getServer().getEntity(id);
            if (!(entity instanceof ArmorStand)) {
                this.spawnHologram(model, data);
                return;
            }
        }
    }

    public void removeHologram(final ActiveEventData data, final World world) {
        if (data == null || data.getHologramIds() == null) {
            return;
        }
        for (final UUID id : data.getHologramIds()) {
            final Entity entity = this.plugin.getServer().getEntity(id);
            if (entity != null) {
                entity.remove();
            }
        }
        data.getHologramIds().clear();
        if (data.getHologramTaskId() != -1) {
            this.plugin.getServer().getScheduler().cancelTask(data.getHologramTaskId());
            data.setHologramTaskId(-1);
        }
    }

    private String[] buildLines(final EventModel model, final ActiveEventData data) {
        final String name = model.getDisplayName();
        final boolean unlocked = data.isShulkerUnlocked();
        final String status = unlocked ? "&a\u0410\u0448\u044b\u049b!" : "&c\u0416\u0430\u0431\u044b\u049b";
        String time;
        if (unlocked) {
            time = "&e\u0410\u0448\u044b\u049b";
        } else {
            final int secondsLeft = data.getCurrentStageSecondsLeft();
            time = "&e" + EventManager.formatTime(secondsLeft);
        }
        return new String[] { name, status, time };
    }

    private ArmorStand spawnStand(final World world, final Location loc, final String name) {
        final ArmorStand stand = (ArmorStand) world.spawnEntity(loc, EntityType.ARMOR_STAND);
        stand.setVisible(false);
        stand.setGravity(false);
        stand.setCanPickupItems(false);
        stand.setCustomNameVisible(true);
        stand.setCustomName(ColorUtil.colorize(name));
        stand.setInvulnerable(true);
        stand.setSmall(true);

        // Persistent so the entity survives chunk unload/reload (server
        // restart, reconnect, etc). Previously this was set to false, which
        // meant the hologram was never saved and disappeared as soon as the
        // chunk unloaded - exactly the bug being fixed here.
        stand.setPersistent(true);

        stand.getScoreboardTags().add("nova_events_hologram");
        return stand;
    }

    private void startUpdateTask(final EventModel model, final ActiveEventData data) {
        if (data.getHologramTaskId() != -1) {
            this.plugin.getServer().getScheduler().cancelTask(data.getHologramTaskId());
        }
        final int taskId = new BukkitRunnable() {
            public void run() {
                if (model.getState() == EventModel.EventState.IDLE || model.getActiveData() != data || data.getHologramIds() == null || data.getHologramIds().isEmpty()) {
                    this.cancel();
                    return;
                }
                HologramManager.this.updateHologram(model, data);
            }
        }.runTaskTimer((Plugin) this.plugin, 20L, 20L).getTaskId();
        data.setHologramTaskId(taskId);
    }
}
