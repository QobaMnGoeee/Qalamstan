package kz.qoba.NovaEvents.models;

import java.util.Collection;
import java.util.ArrayList;
import org.bukkit.inventory.ItemStack;
import java.util.List;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BarColor;

public class EventModel
{
    private final String id;
    private String displayName;
    private String world;
    private boolean enabled;
    private int spawnInterval;
    private int durationSeconds;
    private int maxLootItems;
    private int lootEditorSize;
    private int particleRadius;
    private int pasteYOffset;
    private BarColor bossBarColor;
    private BarStyle bossBarStyle;
    private EventMenuItem menuItem;
    private List<ItemStack> loot;
    private List<EventStage> stages;
    private List<EventParticleConfig> particles;
    private EventState state;
    private long nextSpawnTime;
    private ActiveEventData activeData;
    
    public EventModel(final String id, final String displayName, final String world, final boolean enabled, final int spawnInterval, final int durationSeconds, final int maxLootItems, final int lootEditorSize, final int particleRadius, final int pasteYOffset, final BarColor bossBarColor, final BarStyle bossBarStyle, final EventMenuItem menuItem, final List<EventStage> stages) {
        this.particles = new ArrayList<EventParticleConfig>();
        this.state = EventState.IDLE;
        this.nextSpawnTime = 0L;
        this.activeData = null;
        this.id = id;
        this.displayName = displayName;
        this.world = world;
        this.enabled = enabled;
        this.spawnInterval = spawnInterval;
        this.durationSeconds = durationSeconds;
        this.maxLootItems = maxLootItems;
        this.lootEditorSize = lootEditorSize;
        this.particleRadius = particleRadius;
        this.pasteYOffset = pasteYOffset;
        this.bossBarColor = bossBarColor;
        this.bossBarStyle = bossBarStyle;
        this.menuItem = menuItem;
        this.stages = ((stages == null) ? new ArrayList<EventStage>() : new ArrayList<EventStage>(stages));
        this.loot = new ArrayList<ItemStack>();
    }
    
    public String getId() {
        return this.id;
    }
    
    public String getDisplayName() {
        return this.displayName;
    }
    
    public void setDisplayName(final String displayName) {
        this.displayName = displayName;
    }
    
    public String getWorld() {
        return this.world;
    }
    
    public void setWorld(final String world) {
        this.world = world;
    }
    
    public boolean isEnabled() {
        return this.enabled;
    }
    
    public void setEnabled(final boolean enabled) {
        this.enabled = enabled;
    }
    
    public int getSpawnInterval() {
        return this.spawnInterval;
    }
    
    public void setSpawnInterval(final int spawnInterval) {
        this.spawnInterval = spawnInterval;
    }
    
    public int getDurationSeconds() {
        return this.durationSeconds;
    }
    
    public void setDurationSeconds(final int durationSeconds) {
        this.durationSeconds = durationSeconds;
    }
    
    public int getMaxLootItems() {
        return this.maxLootItems;
    }
    
    public void setMaxLootItems(final int maxLootItems) {
        this.maxLootItems = maxLootItems;
    }
    
    public int getLootEditorSize() {
        return this.lootEditorSize;
    }
    
    public void setLootEditorSize(final int lootEditorSize) {
        this.lootEditorSize = lootEditorSize;
    }
    
    public int getParticleRadius() {
        return this.particleRadius;
    }
    
    public void setParticleRadius(final int particleRadius) {
        this.particleRadius = particleRadius;
    }
    
    public int getPasteYOffset() {
        return this.pasteYOffset;
    }
    
    public void setPasteYOffset(final int pasteYOffset) {
        this.pasteYOffset = pasteYOffset;
    }
    
    public BarColor getBossBarColor() {
        return this.bossBarColor;
    }
    
    public void setBossBarColor(final BarColor bossBarColor) {
        this.bossBarColor = bossBarColor;
    }
    
    public BarStyle getBossBarStyle() {
        return this.bossBarStyle;
    }
    
    public void setBossBarStyle(final BarStyle bossBarStyle) {
        this.bossBarStyle = bossBarStyle;
    }
    
    public EventMenuItem getMenuItem() {
        return this.menuItem;
    }
    
    public void setMenuItem(final EventMenuItem menuItem) {
        this.menuItem = menuItem;
    }
    
    public List<ItemStack> getLoot() {
        return this.loot;
    }
    
    public void setLoot(final List<ItemStack> loot) {
        this.loot = ((loot == null) ? new ArrayList<ItemStack>() : new ArrayList<ItemStack>(loot));
    }
    
    public List<EventStage> getStages() {
        return this.stages;
    }
    
    public void setStages(final List<EventStage> stages) {
        this.stages = ((stages == null) ? new ArrayList<EventStage>() : new ArrayList<EventStage>(stages));
    }
    
    public EventState getState() {
        return this.state;
    }
    
    public void setState(final EventState state) {
        this.state = state;
    }
    
    public long getNextSpawnTime() {
        return this.nextSpawnTime;
    }
    
    public void setNextSpawnTime(final long nextSpawnTime) {
        this.nextSpawnTime = nextSpawnTime;
    }
    
    public ActiveEventData getActiveData() {
        return this.activeData;
    }
    
    public void setActiveData(final ActiveEventData activeData) {
        this.activeData = activeData;
    }
    
    public EventStage getStage(final int index) {
        return (index >= 0 && index < this.stages.size()) ? this.stages.get(index) : null;
    }
    
    public int getStageCount() {
        return this.stages.size();
    }
    
    public boolean hasStages() {
        return !this.stages.isEmpty();
    }
    
    public List<EventParticleConfig> getParticles() {
        return this.particles;
    }
    
    public void setParticles(final List<EventParticleConfig> particles) {
        this.particles = ((particles == null) ? new ArrayList<EventParticleConfig>() : new ArrayList<EventParticleConfig>(particles));
    }
    
    public enum EventState
    {
        IDLE, 
        ACTIVE, 
        OPEN, 
        CLEANING;
        
        private static EventState[] $values() {
            return new EventState[] { EventState.IDLE, EventState.ACTIVE, EventState.OPEN, EventState.CLEANING };
        }
    }
}
