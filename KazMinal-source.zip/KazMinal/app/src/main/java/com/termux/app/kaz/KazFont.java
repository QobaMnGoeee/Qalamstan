package com.termux.app.kaz;

import android.content.Context;
import android.graphics.Typeface;

/**
 * The eight bundled monospace fonts. All of them contain the full Kazakh alphabet
 * (ә і ң ғ ү ұ қ ө һ) and box-drawing characters where the original font has them.
 */
public final class KazFont {

    public final String name;
    public final String asset;
    public final String note;
    private Typeface cached;

    private KazFont(String name, String asset, String note) {
        this.name = name;
        this.asset = asset;
        this.note = note;
    }

    public static final int DEFAULT_INDEX = 0;

    public static final KazFont[] ALL = new KazFont[]{
        new KazFont("Fira Mono", "fonts/kaz_fira_mono.ttf", "Mozilla · жұмсақ, оқуға оңай"),
        new KazFont("Source Code Pro", "fonts/kaz_source_code.ttf", "Adobe · тұп-тура, таза"),
        new KazFont("IBM Plex Mono", "fonts/kaz_plex_mono.ttf", "IBM · қатаң, техникалық"),
        new KazFont("Ubuntu Mono", "fonts/kaz_ubuntu_mono.ttf", "Ubuntu · тар, көп баған"),
        new KazFont("Roboto Mono", "fonts/kaz_roboto_mono.ttf", "Google · заманауи"),
        new KazFont("PT Mono", "fonts/kaz_pt_mono.ttf", "ParaType · кирилл әліпбиіне арналған"),
        new KazFont("Overpass Mono", "fonts/kaz_overpass_mono.ttf", "Red Hat · ашық, кең"),
        new KazFont("Noto Sans Mono", "fonts/kaz_noto_mono.ttf", "Google · барлық тілге"),
    };

    /** Loads (and caches) the typeface. Falls back to the system monospace font on any error. */
    public synchronized Typeface load(Context context) {
        if (cached == null) {
            try {
                cached = Typeface.createFromAsset(context.getApplicationContext().getAssets(), asset);
            } catch (Exception e) {
                cached = Typeface.MONOSPACE;
            }
        }
        return cached;
    }
}
