package kz.qoba.NovaEvents.managers;

import java.util.Locale;
import java.util.Random;
import org.bukkit.block.BlockState;
import org.bukkit.block.Block;
import org.bukkit.Material;
import java.util.Collection;
import org.bukkit.inventory.ItemStack;
import java.util.Collections;
import java.util.ArrayList;
import org.bukkit.block.ShulkerBox;
import org.bukkit.inventory.Inventory;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.WorldEditException;
import com.sk89q.worldedit.regions.CuboidRegion;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import java.util.logging.Logger;
import java.io.IOException;
import java.util.logging.Level;
import org.bukkit.Sound;
import kz.qoba.NovaEvents.utils.ColorUtil;
import java.util.HashMap;
import java.util.List;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BossBar;
import org.bukkit.Location;
import org.bukkit.World;
import kz.qoba.NovaEvents.models.ActiveEventData;
import org.bukkit.entity.Player;
import kz.qoba.NovaEvents.models.EventStage;
import org.bukkit.plugin.Plugin;
import java.util.Iterator;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.Bukkit;
import java.util.concurrent.ConcurrentHashMap;
import java.util.LinkedHashMap;
import java.util.UUID;
import java.util.Set;
import kz.qoba.NovaEvents.models.EventModel;
import java.util.Map;
import kz.qoba.NovaEvents.NovaEvents;

public class EventManager
{
    private final NovaEvents plugin;
    private final Map<String, EventModel> events;
    private int schedulerTaskId;
    private final Set<UUID> shulkerViewers;
    
    public EventManager(final NovaEvents plugin) {
        this.events = new LinkedHashMap<String, EventModel>();
        this.schedulerTaskId = -1;
        this.shulkerViewers = (Set<UUID>)ConcurrentHashMap.newKeySet();
        this.plugin = plugin;
        this.loadEvents();
    }
    
    public void loadEvents() {
        this.events.clear();
        this.events.putAll(this.plugin.getConfigManager().loadEvents());
    }
    
    public Map<String, EventModel> getEvents() {
        return this.events;
    }
    
    public EventModel getEvent(final String id) {
        return this.events.get(id);
    }
    
    public void startScheduler() {
        if (this.schedulerTaskId != -1) {
            Bukkit.getScheduler().cancelTask(this.schedulerTaskId);
        }
        this.schedulerTaskId = new BukkitRunnable() {
            public void run() {
                final long now = System.currentTimeMillis();
                for (final EventModel model : EventManager.this.events.values()) {
                    if (model.isEnabled() && model.getState() == EventModel.EventState.IDLE && now >= model.getNextSpawnTime()) {
                        EventManager.this.spawnEvent(model);
                    }
                }
            }
        }.runTaskTimer((Plugin)this.plugin, 20L, 20L).getTaskId();
    }
    
    public void stopAll() {
        if (this.schedulerTaskId != -1) {
            Bukkit.getScheduler().cancelTask(this.schedulerTaskId);
        }
        for (final EventModel model : this.events.values()) {
            if (model.getState() != EventModel.EventState.IDLE) {
                this.forceStop(model);
            }
        }
    }
    
    public void spawnEvent(final EventModel model) {
        if (model.getState() != EventModel.EventState.IDLE) {
            this.plugin.getLogger().warning("Tried to spawn active event: " + model.getId());
        }
        else {
            final World world = Bukkit.getWorld(model.getWorld());
            if (world == null) {
                this.plugin.getLogger().warning("World not found: " + model.getWorld());
            }
            else {
                for (final EventStage stage : model.getStages()) {
                    if (stage != null && stage.usesSchematic() && !this.plugin.getSchematicManager().schematicExists(stage.getRelativePath())) {
                        Bukkit.getConsoleSender().sendMessage(this.plugin.getConfigManager().getMessage("schematic-not-found", Map.of("file", stage.getRelativePath())));
                        return;
                    }
                }
                final Location spawnLoc = this.findRandomLocation(world);
                if (spawnLoc == null) {
                    this.plugin.getLogger().warning("Could not find valid spawn location for event: " + model.getId());
                }
                else {
                    final int initialDuration = model.hasStages() ? model.getStage(0).getDurationSeconds() : model.getDurationSeconds();
                    final BossBar bossBar = this.createBossBar(model);
                    for (final Player p : Bukkit.getOnlinePlayers()) {
                        bossBar.addPlayer(p);
                    }
                    final ActiveEventData data = new ActiveEventData(spawnLoc, bossBar, initialDuration, this.plugin.getConfigManager().getWorldGuardRegionRadius());
                    data.setCurrentStageIndex(0);
                    model.setState(EventModel.EventState.ACTIVE);
                    model.setActiveData(data);
                    this.broadcastEventSpawn(model, spawnLoc);
                    if (!model.hasStages()) {
                        this.applyStageWithoutSchematic(model, data, 0, this.createRuntimeStage(model, model.getDurationSeconds()));
                    }
                    else {
                        this.beginStage(model, data, 0);
                    }
                }
            }
        }
    }
    
    private BossBar createBossBar(final EventModel model) {
        return Bukkit.createBossBar("", model.getBossBarColor(), model.getBossBarStyle(), new BarFlag[0]);
    }
    
    private EventStage createRuntimeStage(final EventModel model, final int durationSeconds) {
        return new EventStage(model.getId() + "/runtime", "none", false, durationSeconds, 0, 0, 0, List.of());
    }
    
    private void broadcastEventSpawn(final EventModel model, final Location spawnLoc) {
        final Map<String, String> placeholders = new HashMap<String, String>();
        placeholders.put("event_name", ColorUtil.colorize(model.getDisplayName()));
        placeholders.put("world", spawnLoc.getWorld().getName());
        placeholders.put("x", String.valueOf(spawnLoc.getBlockX()));
        placeholders.put("y", String.valueOf(spawnLoc.getBlockY()));
        placeholders.put("z", String.valueOf(spawnLoc.getBlockZ()));
        final String spawnMsg = this.plugin.getConfigManager().getMessage("event-spawn", placeholders);
        final Sound startSound = this.getConfiguredStartSound();
        final float startVolume = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.event-start.volume", 1.0);
        final float startPitch = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.event-start.pitch", 1.0);
        for (final Player p : Bukkit.getOnlinePlayers()) {
            p.sendMessage(spawnMsg);
            p.playSound(p.getLocation(), startSound, startVolume, startPitch);
        }
    }
    
    private void beginStage(final EventModel model, final ActiveEventData data, final int stageIndex) {
        final EventStage stage = model.getStage(stageIndex);
        if (stage == null) {
            this.unlockShulker(model, data);
        }
        else {
            data.setCurrentStageIndex(stageIndex);
            data.setCurrentStageSecondsLeft(stage.getDurationSeconds());
            data.setBossDuration(stage.getDurationSeconds());
            if (!stage.usesSchematic()) {
                final Logger var6 = this.plugin.getLogger();
                final String var7 = model.getId();
                var6.info("Event " + var7 + " stage " + (stageIndex + 1) + ": no schematic (schematic: none or use-schematic: false)");
                Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.applyStageWithoutSchematic(model, data, stageIndex, stage));
            }
            else {
                final String schematicPath = stage.getRelativePath();
                final Logger var8 = this.plugin.getLogger();
                final String var9 = model.getId();
                var8.info("Event " + var9 + " stage " + (stageIndex + 1) + ": loading schematic " + schematicPath);
                Bukkit.getScheduler().runTaskAsynchronously((Plugin)this.plugin, () -> {
                    try {
                        final Clipboard clipboard = this.plugin.getSchematicManager().loadSchematic(schematicPath);
                        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.applyStage(model, data, stageIndex, stage, clipboard));
                    }
                    catch (final IOException e) {
                        this.plugin.getLogger().log(Level.SEVERE, "Error loading stage schematic: " + schematicPath, (Throwable)e);
                        this.forceStop(model);
                    }
                });
            }
        }
    }
    
    private void applyStage(final EventModel model, final ActiveEventData data, final int stageIndex, final EventStage stage, final Clipboard clipboard) {
        if (model.getActiveData() == data && model.getState() != EventModel.EventState.IDLE) {
            final World world = Bukkit.getWorld(model.getWorld());
            if (world == null) {
                this.forceStop(model);
            }
            else {
                try {
                    this.removeEventShulker(model, data);
                    if (data.isSchematicPlaced() || !data.getPlacedBlockPositions().isEmpty()) {
                        this.plugin.getSchematicManager().cleanupSchematic(world, data);
                        data.setSavedRegion(null);
                        data.setSchematicPlaced(false);
                    }
                    final Location anchor = data.getSpawnLocation();
                    final SchematicManager.Placement placement = this.plugin.getSchematicManager().calculatePlacement(clipboard, anchor, world, model.getPasteYOffset());
                    final CuboidRegion region = placement.getWorldRegion();
                    this.ensureChunksLoaded(world, region);
                    final BlockVector3 centerWorld = placement.getCenterWorld();
                    final Logger var10000 = this.plugin.getLogger();
                    final String var10001 = model.getId();
                    var10000.info("Pasting schematic for " + var10001 + " stage " + (stageIndex + 1) + " | shulker center " + centerWorld.x() + ", " + centerWorld.y() + ", " + centerWorld.z() + " | paste min " + placement.getPasteMin().x() + ", " + placement.getPasteMin().y() + ", " + placement.getPasteMin().z() + " | volume " + region.getVolume());
                    this.plugin.getSchematicManager().prepareAndPaste(clipboard, world, placement, data);
                    data.setSavedRegion(region);
                    data.setParticleRegion(region);
                    data.setSchematicOrigin(placement.getPasteMin());
                    data.setSchematicCenterWorld(centerWorld);
                    data.setSchematicPlaced(true);
                    this.finishStageSetup(model, data, stageIndex, stage);
                }
                catch (final WorldEditException e) {
                    this.plugin.getLogger().log(Level.SEVERE, "WorldEdit error pasting stage schematic", (Throwable)e);
                    this.forceStop(model);
                }
            }
        }
    }
    
    private void applyStageWithoutSchematic(final EventModel model, final ActiveEventData data, final int stageIndex, final EventStage stage) {
        if (model.getActiveData() == data && model.getState() != EventModel.EventState.IDLE) {
            final World world = Bukkit.getWorld(model.getWorld());
            if (world == null) {
                this.forceStop(model);
            }
            else {
                this.removeEventShulker(model, data);
                if (data.isSchematicPlaced() || !data.getPlacedBlockPositions().isEmpty()) {
                    this.plugin.getSchematicManager().cleanupSchematic(world, data);
                    data.setSavedRegion(null);
                    data.setSchematicPlaced(false);
                }
                final Location center = data.getSpawnLocation();
                data.setParticleRegion(this.plugin.getParticleEffectManager().createRegionAround(center, model.getParticleRadius()));
                this.finishStageSetup(model, data, stageIndex, stage);
            }
        }
    }
    
    private void finishStageSetup(final EventModel model, final ActiveEventData data, final int stageIndex, final EventStage stage) {
        final World world = Bukkit.getWorld(model.getWorld());
        if (world == null) {
            this.forceStop(model);
        }
        else {
            if (data.getWorldGuardRegionId() == null) {
                final Location wgCenter = (data.getSchematicCenterWorld() != null) ? new Location(world, data.getSchematicCenterWorld().x() + 0.5, (double)data.getSchematicCenterWorld().y(), data.getSchematicCenterWorld().z() + 0.5) : data.getSpawnLocation();
                final String regionId = this.plugin.getWorldGuardRegionManager().createEventRegion(model.getId(), wgCenter, data.getProtectedRadius());
                data.setWorldGuardRegionId(regionId);
            }
            Location shulkerBase;
            if (data.getSchematicCenterWorld() != null) {
                final BlockVector3 center = data.getSchematicCenterWorld();
                shulkerBase = new Location(world, (double)center.x(), (double)center.y(), (double)center.z());
            }
            else {
                shulkerBase = data.getSpawnLocation();
            }
            final Location shulkerLoc = new Location(world, (double)(shulkerBase.getBlockX() + stage.getShulkerOffsetX()), (double)(shulkerBase.getBlockY() + stage.getShulkerOffsetY()), (double)(shulkerBase.getBlockZ() + stage.getShulkerOffsetZ()));
            data.setShulkerLocation(shulkerLoc);
            this.placeEventShulkerBlock(model, data, this.buildLockedShulkerName(model));
            this.plugin.getHologramManager().spawnHologram(model, data);
            this.plugin.getParticleEffectManager().startForStage(model, data, stage);
            this.startBossBarCountdown(model, data, stageIndex, stage.getDurationSeconds());
        }
    }
    
    private void startBossBarCountdown(final EventModel model, final ActiveEventData data, final int stageIndex, final int totalSeconds) {
        if (data.getBossBarTaskId() != -1) {
            Bukkit.getScheduler().cancelTask(data.getBossBarTaskId());
        }
        data.getBossBar().setProgress(1.0);
        data.getBossBar().setTitle(this.buildBossBarTitle(model, data.getSpawnLocation(), totalSeconds, stageIndex));
        final int taskId = new BukkitRunnable() {
            int secondsLeft = totalSeconds;
            
            public void run() {
                if (model.getState() == EventModel.EventState.ACTIVE && model.getActiveData() == data && data.getCurrentStageIndex() == stageIndex) {
                    --this.secondsLeft;
                    data.setCurrentStageSecondsLeft(this.secondsLeft);
                    data.getBossBar().setProgress(Math.max(0.0, this.secondsLeft / (double)Math.max(1, totalSeconds)));
                    data.getBossBar().setTitle(EventManager.this.buildBossBarTitle(model, data.getSpawnLocation(), this.secondsLeft, stageIndex));
                    if (this.secondsLeft <= 0) {
                        this.cancel();
                        if (stageIndex + 1 < model.getStageCount()) {
                            EventManager.this.beginStage(model, data, stageIndex + 1);
                        }
                        else {
                            EventManager.this.unlockShulker(model, data);
                        }
                    }
                }
                else {
                    this.cancel();
                }
            }
        }.runTaskTimer((Plugin)this.plugin, 20L, 20L).getTaskId();
        data.setBossBarTaskId(taskId);
    }
    
    private void unlockShulker(final EventModel model, final ActiveEventData data) {
        model.setState(EventModel.EventState.OPEN);
        data.setShulkerUnlocked(true);
        data.getBossBar().removeAll();
        this.updateShulkerBlockName(model, data, this.buildUnlockedShulkerName(model));
        this.plugin.getHologramManager().updateHologram(model, data);
        final String msg = this.plugin.getConfigManager().getMessage("event-end", Map.of("event_name", ColorUtil.colorize(model.getDisplayName())));
        for (final Player p : Bukkit.getOnlinePlayers()) {
            p.sendMessage(msg);
            p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.0f);
        }
        final int cleanupDelay = this.plugin.getConfigManager().getCleanupDelay();
        final int taskId = new BukkitRunnable() {
            public void run() {
                EventManager.this.cleanupEvent(model);
            }
        }.runTaskLater((Plugin)this.plugin, cleanupDelay * 20L).getTaskId();
        data.setCleanupTaskId(taskId);
    }
    
    public void cleanupEvent(final EventModel model) {
        model.setState(EventModel.EventState.CLEANING);
        final ActiveEventData data = model.getActiveData();
        if (data == null) {
            this.resetEvent(model);
        }
        else {
            this.closeAllShulkerViewers(data);
            this.removeEventShulker(model, data);
            final World world = Bukkit.getWorld(model.getWorld());
            if (world != null) {
                this.plugin.getHologramManager().removeHologram(data, world);
                this.plugin.getSchematicManager().cleanupSchematic(world, data);
                data.setSchematicPlaced(false);
                this.plugin.getWorldGuardRegionManager().removeRegion(world, data.getWorldGuardRegionId());
            }
            final String msg = this.plugin.getConfigManager().getMessage("event-cleanup", Map.of("event_name", ColorUtil.colorize(model.getDisplayName())));
            for (final Player p : Bukkit.getOnlinePlayers()) {
                p.sendMessage(msg);
            }
            this.resetEvent(model);
        }
    }
    
    private void closeAllShulkerViewers(final ActiveEventData data) {
        for (final Player p : Bukkit.getOnlinePlayers()) {
            if (this.shulkerViewers.contains(p.getUniqueId())) {
                p.closeInventory();
            }
        }
        this.shulkerViewers.clear();
    }
    
    private void resetEvent(final EventModel model) {
        final ActiveEventData data = model.getActiveData();
        if (data != null) {
            if (data.getBossBarTaskId() != -1) {
                Bukkit.getScheduler().cancelTask(data.getBossBarTaskId());
            }
            if (data.getCleanupTaskId() != -1) {
                Bukkit.getScheduler().cancelTask(data.getCleanupTaskId());
            }
            if (data.getLootPopulateTaskId() != -1) {
                Bukkit.getScheduler().cancelTask(data.getLootPopulateTaskId());
            }
            this.plugin.getParticleEffectManager().stop(data);
            data.getBossBar().removeAll();
        }
        model.setActiveData(null);
        model.setState(EventModel.EventState.IDLE);
        model.setNextSpawnTime(System.currentTimeMillis() + model.getSpawnInterval() * 60L * 1000L);
    }
    
    public void forceStop(final EventModel model) {
        if (model.getState() != EventModel.EventState.IDLE) {
            final ActiveEventData data = model.getActiveData();
            if (data != null) {
                if (data.getBossBarTaskId() != -1) {
                    Bukkit.getScheduler().cancelTask(data.getBossBarTaskId());
                }
                if (data.getCleanupTaskId() != -1) {
                    Bukkit.getScheduler().cancelTask(data.getCleanupTaskId());
                }
                if (data.getLootPopulateTaskId() != -1) {
                    Bukkit.getScheduler().cancelTask(data.getLootPopulateTaskId());
                }
                this.plugin.getParticleEffectManager().stop(data);
                this.closeAllShulkerViewers(data);
                this.removeEventShulker(model, data);
                final World world = Bukkit.getWorld(model.getWorld());
                if (world != null) {
                    this.plugin.getHologramManager().removeHologram(data, world);
                    this.plugin.getSchematicManager().cleanupSchematic(world, data);
                    data.setSchematicPlaced(false);
                    this.plugin.getWorldGuardRegionManager().removeRegion(world, data.getWorldGuardRegionId());
                }
                data.getBossBar().removeAll();
            }
            model.setActiveData(null);
            model.setState(EventModel.EventState.IDLE);
            model.setNextSpawnTime(System.currentTimeMillis() + model.getSpawnInterval() * 60L * 1000L);
        }
    }
    
    public boolean openShulkerForPlayer(final Player player, final EventModel model) {
        final ActiveEventData data = model.getActiveData();
        if (data == null || !data.isShulkerUnlocked()) {
            player.sendMessage(this.plugin.getConfigManager().getMessage("shulker-locked"));
            return false;
        }
        if (data.isShulkerOpened() && data.getPlayerHasLooted().getOrDefault(player.getUniqueId(), false)) {
            return false;
        }
        if (!data.isShulkerOpened()) {
            data.setShulkerOpened(true);
            this.updateShulkerOpenedAppearance(model, data);
        }
        if (!data.isLootGenerated() && !data.isLootPopulating()) {
            this.populateShulkerLoot(model, data);
        }
        final Inventory inv = this.getShulkerInventory(model, data);
        if (inv == null) {
            return false;
        }
        this.shulkerViewers.add(player.getUniqueId());
        player.openInventory(inv);
        return true;
    }
    
    private Inventory getShulkerInventory(final EventModel model, final ActiveEventData data) {
        if (data.getLootInventory() != null) {
            return data.getLootInventory();
        }
        final ShulkerBox shulkerBox = this.getShulkerBox(data);
        if (shulkerBox == null) {
            return null;
        }
        data.setLootInventory(shulkerBox.getInventory());
        return data.getLootInventory();
    }
    
    private void populateShulkerLoot(final EventModel model, final ActiveEventData data) {
        final Inventory shulkerInv = this.getShulkerInventory(model, data);
        if (shulkerInv == null) {
            data.setLootGenerated(true);
        }
        else {
            final List<ItemStack> configuredLoot = model.getLoot();
            if (configuredLoot != null && !configuredLoot.isEmpty()) {
                shulkerInv.clear();
                final int maxItems = Math.max(1, model.getMaxLootItems());
                final int slotCount = shulkerInv.getSize();
                final List<Integer> slots = new ArrayList<Integer>();
                for (int i = 0; i < slotCount; ++i) {
                    slots.add(i);
                }
                Collections.shuffle(slots);
                final List<ItemStack> available = new ArrayList<ItemStack>(configuredLoot);
                Collections.shuffle(available);
                final int toPlace = Math.min(maxItems, Math.min(27, Math.min(available.size(), slots.size())));
                if (toPlace <= 0) {
                    data.setLootGenerated(true);
                }
                else {
                    data.setLootPopulating(true);
                    final int taskId = new BukkitRunnable() {
                        int index = 0;
                        
                        public void run() {
                            if (model.getState() != EventModel.EventState.IDLE && model.getActiveData() == data) {
                                if (this.index >= toPlace) {
                                    data.setLootPopulating(false);
                                    data.setLootGenerated(true);
                                    data.setLootPopulateTaskId(-1);
                                    EventManager.this.updateShulkerBoxState(data);
                                    this.cancel();
                                }
                                else {
                                    shulkerInv.setItem((int)slots.get(this.index), available.get(this.index).clone());
                                    ++this.index;
                                }
                            }
                            else {
                                data.setLootPopulating(false);
                                data.setLootPopulateTaskId(-1);
                                this.cancel();
                            }
                        }
                    }.runTaskTimer((Plugin)this.plugin, 0L, 6L).getTaskId();
                    data.setLootPopulateTaskId(taskId);
                }
            }
            else {
                data.setLootGenerated(true);
            }
        }
    }
    
    private void placeEventShulkerBlock(final EventModel model, final ActiveEventData data, final String customName) {
        final Location shulkerLocation = data.getShulkerLocation();
        if (shulkerLocation != null && shulkerLocation.getWorld() != null) {
            final Block block = shulkerLocation.getBlock();
            block.setType(Material.SHULKER_BOX, false);
            final BlockState var7 = block.getState();
            if (var7 instanceof final ShulkerBox shulkerBox) {
                shulkerBox.getInventory().clear();
                shulkerBox.setCustomName(customName);
                shulkerBox.update(true, false);
                data.setLootInventory(shulkerBox.getInventory());
            }
        }
    }
    
    private void updateShulkerBlockName(final EventModel model, final ActiveEventData data, final String customName) {
        final ShulkerBox shulkerBox = this.getShulkerBox(data);
        if (shulkerBox != null) {
            shulkerBox.setCustomName(customName);
            shulkerBox.update(true, false);
            data.setLootInventory(shulkerBox.getInventory());
        }
    }
    
    private void updateShulkerBoxState(final ActiveEventData data) {
        final ShulkerBox shulkerBox = this.getShulkerBox(data);
        if (shulkerBox != null) {
            shulkerBox.update(true, false);
            data.setLootInventory(shulkerBox.getInventory());
        }
    }
    
    private ShulkerBox getShulkerBox(final ActiveEventData data) {
        if (data == null || data.getShulkerLocation() == null || data.getShulkerLocation().getWorld() == null) {
            return null;
        }
        final Block block = data.getShulkerLocation().getBlock();
        final BlockState var4 = block.getState();
        if (var4 instanceof final ShulkerBox shulkerBox) {
            return shulkerBox;
        }
        return null;
    }
    
    private void removeEventShulker(final EventModel model, final ActiveEventData data) {
        data.setLootInventory(null);
        final Location shulkerLocation = data.getShulkerLocation();
        if (shulkerLocation != null && shulkerLocation.getWorld() != null) {
            final Block block = shulkerLocation.getBlock();
            if (block.getType() == Material.SHULKER_BOX) {
                block.setType(Material.AIR, false);
            }
        }
    }
    
    public void registerShulkerViewer(final UUID uuid) {
        this.shulkerViewers.add(uuid);
    }
    
    public void unregisterShulkerViewer(final UUID uuid) {
        this.shulkerViewers.remove(uuid);
    }
    
    public boolean isShulkerViewer(final UUID uuid) {
        return this.shulkerViewers.contains(uuid);
    }
    
    public EventModel getEventByShulkerBlock(final Block block) {
        if (block != null && block.getType() == Material.SHULKER_BOX) {
            for (final EventModel model : this.events.values()) {
                final ActiveEventData data = model.getActiveData();
                if (data != null && data.getShulkerLocation() != null && block.getWorld().getUID().equals(data.getShulkerLocation().getWorld().getUID()) && block.getX() == data.getShulkerLocation().getBlockX() && block.getY() == data.getShulkerLocation().getBlockY() && block.getZ() == data.getShulkerLocation().getBlockZ()) {
                    return model;
                }
            }
            return null;
        }
        return null;
    }
    
    public EventModel getProtectedEventAt(final Location location) {
        if (location != null && location.getWorld() != null) {
            for (final EventModel model : this.events.values()) {
                final ActiveEventData data = model.getActiveData();
                if (data != null && data.isInProtectedRadius(location)) {
                    return model;
                }
            }
            return null;
        }
        return null;
    }
    
    public boolean canModifyProtectedZone(final Player player, final Location location) {
        final EventModel model = this.getProtectedEventAt(location);
        return model == null || player.hasPermission("NovaEvents.admin") || player.isOp();
    }
    
    public boolean teleportToEvent(final Player player, final EventModel model) {
        if (model != null && model.getActiveData() != null && model.getState() != EventModel.EventState.IDLE) {
            final Location base = model.getActiveData().getSpawnLocation().clone().add(0.5, 1.0, 0.5);
            final Location target = new Location(base.getWorld(), base.getX(), base.getY(), base.getZ(), player.getLocation().getYaw(), player.getLocation().getPitch());
            player.teleport(target);
            return true;
        }
        return false;
    }
    
    private void ensureChunksLoaded(final World world, final CuboidRegion region) {
        final BlockVector3 min = region.getMinimumPoint();
        final BlockVector3 max = region.getMaximumPoint();
        final int minChunkX = min.x() >> 4;
        final int maxChunkX = max.x() >> 4;
        final int minChunkZ = min.z() >> 4;
        final int maxChunkZ = max.z() >> 4;
        for (int cx = minChunkX; cx <= maxChunkX; ++cx) {
            for (int cz = minChunkZ; cz <= maxChunkZ; ++cz) {
                world.getChunkAt(cx, cz).load(true);
            }
        }
    }
    
    private Location findRandomLocation(final World world) {
        final int radius = this.plugin.getConfigManager().getSpawnRadius();
        final int minRadius = this.plugin.getConfigManager().getSpawnMinRadius();
        final int attempts = this.plugin.getConfigManager().getSpawnAttempts();
        final Random random = new Random();
        for (int attempt = 0; attempt < attempts; ++attempt) {
            final double angle = random.nextDouble() * 2.0 * 3.141592653589793;
            final double dist = minRadius + random.nextDouble() * Math.max(1, radius - minRadius);
            final int x = (int)(Math.cos(angle) * dist);
            final int z = (int)(Math.sin(angle) * dist);
            final int groundY = world.getHighestBlockYAt(x, z);
            final int y = groundY + 1;
            if (y > world.getMinHeight() && y < world.getMaxHeight() - 10 && !this.isForbiddenSpawnPoint(world, x, groundY, z)) {
                return new Location(world, (double)x, (double)y, (double)z);
            }
        }
        return null;
    }
    
    private boolean isForbiddenSpawnPoint(final World world, final int x, final int y, final int z) {
        final Material surface = world.getBlockAt(x, y, z).getType();
        if (surface != Material.WATER && surface != Material.KELP && surface != Material.KELP_PLANT && surface != Material.SEAGRASS && surface != Material.TALL_SEAGRASS) {
            final String biome = world.getBiome(x, y, z).getKey().getKey().toUpperCase(Locale.ROOT);
            for (final String forbidden : this.plugin.getConfigManager().getForbiddenSpawnBiomes()) {
                final String check = forbidden.toUpperCase(Locale.ROOT);
                if (biome.equals(check) || biome.contains(check)) {
                    return true;
                }
            }
            return false;
        }
        return true;
    }
    
    private String buildBossBarTitle(final EventModel model, final Location location, final int secondsLeft, final int stageIndex) {
        return ColorUtil.colorize(this.plugin.getConfigManager().getConfig().getString("messages.bossbar-title", "&e{event_name} &7| &6{x}, {z} &7| &f{time}").replace("{event_name}", ColorUtil.colorize(model.getDisplayName())).replace("{x}", String.valueOf(location.getBlockX())).replace("{z}", String.valueOf(location.getBlockZ())).replace("{time}", formatTime(secondsLeft)).replace("{stage}", String.valueOf(stageIndex + 1)).replace("{stage_total}", String.valueOf(Math.max(1, model.getStageCount()))));
    }
    
    private String buildLockedShulkerName(final EventModel model) {
        return ColorUtil.colorize(this.plugin.getConfigManager().getConfig().getString("messages.shulker-locked-name", "&c\ud83d\udd12 " + model.getDisplayName() + "&f"));
    }
    
    private String buildUnlockedShulkerName(final EventModel model) {
        return ColorUtil.colorize(this.plugin.getConfigManager().getConfig().getString("messages.shulker-unlocked-name", "&a\ud83d\udd13 " + model.getDisplayName() + "&f"));
    }
    
    private String buildOpenedShulkerName(final EventModel model) {
        return ColorUtil.colorize(this.plugin.getConfigManager().getConfig().getString("messages.shulker-opened-name", "&a\ud83d\udd13 " + model.getDisplayName() + "&7 (\u0430\u0448\u044b\u049b)"));
    }
    
    private void updateShulkerOpenedAppearance(final EventModel model, final ActiveEventData data) {
        this.updateShulkerBlockName(model, data, this.buildOpenedShulkerName(model));
    }
    
    private Sound getConfiguredStartSound() {
        final String raw = this.plugin.getConfigManager().getConfig().getString("sounds.event-start.sound", "ENTITY_PLAYER_LEVELUP");
        try {
            return Sound.valueOf(raw.toUpperCase(Locale.ROOT));
        }
        catch (final Exception var3) {
            return Sound.ENTITY_PLAYER_LEVELUP;
        }
    }
    
    public static String formatTime(final int totalSeconds) {
        if (totalSeconds <= 0) {
            return "0\u0441";
        }
        final int hours = totalSeconds / 3600;
        final int minutes = totalSeconds % 3600 / 60;
        final int seconds = totalSeconds % 60;
        if (hours > 0) {
            return hours + "\u0441 " + minutes + "\u043c " + seconds;
        }
        return (minutes > 0) ? (minutes + "\u043c " + seconds) : ("" + seconds);
    }
    
    public String getTimeUntilNextSpawn(final EventModel model) {
        if (model.getState() != EventModel.EventState.IDLE) {
            return "\u0411\u0435\u043b\u0441\u0435\u043d\u0434\u0456";
        }
        final long diff = model.getNextSpawnTime() - System.currentTimeMillis();
        return (diff <= 0L) ? "\u0416\u0430\u049b\u044b\u043d \u0430\u0440\u0430\u0434\u0430..." : formatTime((int)(diff / 1000L));
    }
}
